// foodhub-footer.js

const footerHTML = `
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #ff0000;
      --secondary-color: #000000;
      --light-color: #ffffff;
      --text-color: #cccccc;
    }

    .footer {
      background-color: var(--secondary-color);
      color: var(--light-color);
      padding: 40px 20px 20px;
      font-family: 'Segoe UI', sans-serif;
    }

    .footer-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 20px;
      max-width: 1200px;
      margin: 50px auto 0;
    }

    .footer-container > div {
      flex: 1;
      min-width: 200px;
      margin: 10px 0;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      text-align: center;
    }

    .footer h3, .footer h4 {
      margin-bottom: 15px;
      color: var(--primary-color);
    }

    .footer p, .footer ul, .footer a {
      color: var(--text-color);
      font-size: 14px;
    }

    .footer ul {
      list-style: none;
      padding: 0;
    }

    .footer a {
      text-decoration: none;
      display: block;
      margin-bottom: 8px;
      position: relative;
      transition: color 0.3s ease, transform 0.3s ease;
    }

    .footer a:hover {
      color: var(--primary-color);
      transform: translateX(5px);
    }

    .footer-links ul li a::before {
      content: "\\f105";
      font-family: 'Font Awesome 6 Free';
      font-weight: 900;
      margin-right: 8px;
      color: var(--primary-color);
      transition: transform 0.3s ease;
    }

    .footer-links ul li a:hover::before {
      transform: translateX(3px);
    }

    .footer-social .social-icons {
      display: flex;
      align-items: center;
      gap: 15px;
      justify-content: center;
    }

    .footer-social .social-icons a {
      color: var(--text-color);
      font-size: 20px;
      transition: color 0.3s ease, transform 0.3s ease;
    }

    .footer-social .social-icons a:hover {
      transform: scale(1.2);
    }

    .footer-social .social-icons a[href*="facebook"]:hover {
      color: #3b5998;
    }

    .footer-social .social-icons a[href*="twitter"]:hover {
      color: #1da1f2;
    }

    .footer-social .social-icons a[href*="instagram"]:hover {
      background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .footer-social .social-icons a[href*="youtube"]:hover {
      color: #ff0000;
    }

    .footer-contact p i {
      margin-right: 8px;
      color: var(--primary-color);
    }

    .footer-bottom {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      padding-top: 20px;
      border-top: 1px solid #444;
      font-size: 13px;
      color: #aaa;
    }

    .footer-bottom .footer-info,
    .footer-bottom .footer-extra-links {
      display: flex;
      gap: 15px;
      align-items: center;
      margin: 10px 0;
      flex-wrap: wrap;
      justify-content: center;
      width: 100%;
    }

    .footer-bottom .footer-extra-links a {
      color: #aaa;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .footer-bottom .footer-extra-links a:hover {
      color: var(--primary-color);
    }

    /* Two sections per row when screen is 768px or smaller */
    @media (max-width: 768px) {
      .footer-container > div {
        flex: 1 1 48%;
      }
    }

    /* Font tweaks for smaller mobile */
    @media (max-width: 480px) {
      .footer p, .footer a {
        font-size: 13px;
      }

      .footer h3, .footer h4 {
        font-size: 18px;
      }

      .footer-social .social-icons a {
        font-size: 18px;
      }

      .footer-bottom {
        font-size: 12px;
      }
    }
  </style>

  <footer class="footer">
    <div class="footer-container">
      <div class="footer-about">
        <h3>FoodHub</h3>
        <p>Your favorite meals delivered fresh to your door. Quick, easy, and delicious!</p>
      </div>
      <div class="footer-links">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#"><i class="fas fa-angle-right"></i> Home</a></li>
          <li><a href="#"><i class="fas fa-angle-right"></i> Menu</a></li>
          <li><a href="#"><i class="fas fa-angle-right"></i> Order Now</a></li>
          <li><a href="#"><i class="fas fa-angle-right"></i> Drive-Through</a></li>
          <li><a href="#"><i class="fas fa-angle-right"></i> Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-contact">
        <h4>Contact Us</h4>
        <p><i class="fas fa-envelope"></i>Email: support@foodhub.com</p>
        <p><i class="fas fa-phone"></i>Phone: +1 (800) 123-4567</p>
        <p><i class="fas fa-map-marker-alt"></i>Address: 123 Food St, Flavor Town, USA</p>
      </div>
      <div class="footer-social">
        <h4>Follow Us</h4>
        <div class="social-icons">
          <a href="https://www.facebook.com/foodhub" target="_blank"><i class="fab fa-facebook-f"></i></a>
          <a href="https://www.twitter.com/foodhub" target="_blank"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/foodhub" target="_blank"><i class="fab fa-instagram"></i></a>
          <a href="https://www.youtube.com/foodhub" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="footer-info">
        <p>&copy; 2025 FoodHub. All rights reserved.</p>
      </div>
      <div class="footer-extra-links">
        <a href="#"><i class="fas fa-home"></i> Home</a>
        <a href="#"><i class="fas fa-cookie-bite"></i> Cookies</a>
        <a href="#"><i class="fas fa-question-circle"></i> FAQs</a>
        <a href="#"><i class="fas fa-hands-helping"></i> Help</a>
      </div>
    </div>
  </footer>
`;

document.addEventListener("DOMContentLoaded", () => {
  const container = document.createElement("div");
  container.innerHTML = footerHTML;
  document.body.appendChild(container);
});
