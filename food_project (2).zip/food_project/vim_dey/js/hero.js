const heroSection = `
<div class="hero" id="hero">
    <div class="nav">
        <button onclick="prevSlide()">❮</button>
        <button onclick="nextSlide()">❯</button>
    </div>
    <div class="hero-slider">
        <div class="hero-slide" style="background-image: url('img/Spaghetti.jpeg');"></div>
        // <div class="hero-slide" style="background-image: url('img/hero (2).jpeg');"></div>
        <div class="hero-slide" style="background-image: url('img/hero (3).jpeg');"></div>
    </div>
    <div class="hero-text" id="text1">
        <h1>Welcome to FoodHub</h1>
        <p>Your journey to delicious meals starts here.</p>
        <button class="hero-button">Get Started</button>
    </div>
    <div class="hero-text" id="text2">
        <h1>Discover New Recipes</h1>
        <p>Explore a variety of cuisines and flavors.</p>
        <button class="hero-button">Explore Now</button>
    </div>
    <div class="hero-text" id="text3">
        <h1>Plan Your Meals</h1>
        <p>Effortlessly organize your meals for the week.</p>
        <button class="hero-button">Meal Planner</button>
    </div>
</div>
`;

document.body.innerHTML += heroSection;

let currentSlide = 0;

function showSlide(index) {
    const slides = document.querySelector('.hero-slider');
    const texts = document.querySelectorAll('.hero-text');
    
    if (index < 0) {
        currentSlide = 2; // Loop to last slide
    } else if (index > 2) {
        currentSlide = 0; // Loop to first slide
    } else {
        currentSlide = index;
    }

    // Update the active classes
    slides.style.transform = `translateX(-${currentSlide * 100}%)`;
    
    // Hide all texts and show the current one
    texts.forEach((text, i) => {
        text.classList.remove('active');
        if (i === currentSlide) {
            text.classList.add('active');
        }
    });
}

function nextSlide() {
    showSlide(currentSlide + 1);
}

function prevSlide() {
    showSlide(currentSlide - 1);
}

// Automatic slide change
setInterval(nextSlide, 10000); // Change slide every 5 seconds

// Show the initial slide
showSlide(currentSlide);

// Add CSS styles
const styles = `
<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
    }

    .hero {
        box-shadow: inset 0 4px 30px rgba(141, 22, 22, 0.82);
        position: relative;
        height: 80vh;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f0f0f0;
    }

    .hero-slider {
                box-shadow: inset 0 4px 30px rgba(141, 22, 22, 0.82);
        
        z-index: 2;
        display: flex;
        transition: transform 1s ease;
        width: 300%; /* 3 images */
        height: 100%;
    }

    .hero-slide {
                box-shadow: inset 2px 4px 20px rgb(196, 196, 196);

        min-width: 100%; /* Each slide takes full width */
        height: 100%;
        background-size: cover;
        background-position: center;
    }

    .hero-text {
        text-shadow:1px 5px 10px black;
        z-index: 3;
        position: absolute;
        text-align: center; /* Center text */
        width: 100%; /* Full width for centering */
        transform: translateY(100%); /* Start off-screen */
        opacity: 0;
        transition: transform 1s ease, opacity 1s ease;
        color: white;
    }

    .hero-text.active {
        transform: translateY(0); /* Slide in */
        opacity: 1; /* Fade in */
    }

    .hero-button {
        box-shadow: 1px 2px 10px black;
        margin-top: 20px;
        padding: 10px 20px;
        background-color:rgba(7, 7, 7, 0.85);
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .hero-button:hover {
        background-color:rgb(0, 0, 0);
    }

    /* Navigation styles */
    .nav {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        color: white;
        display: flex;
        justify-content: space-between;
        width: 100%;
        padding: 0 20px; /* Add padding to the sides */
        z-index: 10; /* Ensure buttons are on top */
    }

    .nav button {
        background: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
        border: none;
        color: white;
        cursor: pointer;
        font-size: 30px; /* Larger buttons */
        padding: 10px; /* Padding for better click area */
        border-radius: 5px; /* Rounded corners */
    }

    .nav button:hover {
        background: rgba(0, 0, 0, 0.7); /* Darker on hover */
    }
</style>
`;

document.head.innerHTML += styles;