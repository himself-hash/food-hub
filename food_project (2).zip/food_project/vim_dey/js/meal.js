const mealsSection = `
<div class="order-count" id="orderCountContainer">
  <div class="circle" id="orderCircle">0</div>
</div>
<div class="card-container">
  <article class="dish-card" role="region" aria-label="Dish: Margherita Pizza">
    <img src="img/pizza (1).jpeg" alt="Margherita Pizza" />
    <h2>Margherita Pizza</h2>
    <span class="price">$12.99</span>
    <button type="button" aria-label="Add Margherita Pizza to your order">Add to Order</button>
  </article>
  
  <article class="dish-card" role="region" aria-label="Dish: Pepperoni Pizza">
    <img src="img/hero (2).jpeg" alt="Pepperoni Pizza" />
    <h2>Pepperoni Pizza</h2>
    <span class="price">$14.99</span>
    <button type="button" aria-label="Add Pepperoni Pizza to your order">Add to Order</button>
  </article>

  <article class="dish-card" role="region" aria-label="Dish: Caesar Salad">
    <img src="img/caesarsalad.jpeg" alt="Caesar Salad" />
    <h2>Caesar Salad</h2>
    <span class="price">$9.99</span>
    <button type="button" aria-label="Add Caesar Salad to your order">Add to Order</button>
  </article>

  <article class="dish-card" role="region" aria-label="Dish: Spaghetti Carbonara">
    <img src="img/Spaghetti.jpeg" alt="Spaghetti Carbonara" />
    <h2>Spaghetti Carbonara</h2>
    <span class="price">$13.99</span>
    <button type="button" aria-label="Add Spaghetti Carbonara to your order">Add to Order</button>
  </article>

  <article class="dish-card" role="region" aria-label="Dish: Fried Rice">
    <img src="img/friedrice (2).jpeg" alt="Fried Rice" />
    <h2>Fried Rice</h2>
    <span class="price">$10.99</span>
    <button type="button" aria-label="Add Fried Rice to your order">Add to Order</button>
  </article>

  <article class="dish-card" role="region" aria-label="Dish: Jollof Rice">
    <img src="img/jollofrice (1).jpeg" alt="Jollof Rice" />
    <h2>Jollof Rice</h2>
    <span class="price">$11.99</span>
    <button type="button" aria-label="Add Jollof Rice to your order">Add to Order</button>
  </article>

  <article class="dish-card" role="region" aria-label="Dish: Whole Chicken">
    <img src="img/hero (1).jpeg" alt="Whole Chicken" />
    <h2>Whole Chicken</h2>
    <span class="price">$19.99</span>
    <button type="button" aria-label="Add Whole Chicken to your order">Add to Order</button>
  </article>

  <article class="dish-card" role="region" aria-label="Dish: Chicken Fried Rice">
    <img src="img/friedrice (1).jpeg" alt="Chicken Fried Rice" />
    <h2>Chicken Fried Rice</h2>
    <span class="price">$12.99</span>
    <button type="button" aria-label="Add Chicken Fried Rice to your order">Add to Order</button>
  </article>
</div>

<!-- Modal for selecting quantity -->
<div id="quantityModal" class="modal">
  <div class="modal-content">
    <span class="close-button">&times;</span>
    <h2>Select Quantity</h2>
    <input type="number" id="quantityInput" value="1" min="1" style="width: 60%; margin: 0 auto;"/>
    <button id="confirmOrderButton" style="width: 60%; margin: 10px auto; display: block;">Confirm Order</button>
    <img id="modalFoodImage" src="" alt="" style="width: 70px; height: 70px; border-radius: 8px; margin-top: 10px;" />
    <p id="foodName" style="margin-top: 10px;"></p>
  </div>
</div>
`;

// Insert the meals section into the body
document.body.innerHTML += mealsSection;

// Add CSS styles for the meal cards, order circle, and modal
const mealStyles = `
<style>
  body {
      background-color: #333; /* Background color for contrast */
      color: white; /* Default text color */
  }

  .order-count {
      position: sticky; /* Make it sticky */
      top: 20px; /* Space from the top of the viewport */
      display: flex;
      justify-content: flex-end;
      align-items: center;
      margin-bottom: 20px; /* Space below the circle */
      z-index: 10; /* Ensure it stays on top */
      transition: margin-top 0.3s ease, top 0.3s ease; /* Smooth transition for margin and top */
  }

  .order-count.scrolled {
      margin-top: 50px; /* Margin when scrolled */
  }

  .circle {
      width: 30px;
      height: 30px;
      background-color: red;
      border-radius: 50%;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      margin-left: 10px; /* Space between circle and text */
      transition: top 0.3s ease; /* Smooth transition for top */
  }

  .card-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1.5rem; /* Space between cards */
  }

  .dish-card {
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      width: 100%;
      max-width: 320px;
      text-align: center;
      opacity: 0; /* Start with hidden opacity */
      transform: translateX(-50px); /* Start with a slight left position */
      transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
  }

  .dish-card.show {
      opacity: 1; /* Fade in */
      transform: translateX(0); /* Move to original position */
  }

  .dish-card.active {
      background-color: lightgrey; /* Change background to light grey when active */
  }

  .dish-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
  }

  .dish-card img {
      width: 100%;
      height: auto;
      aspect-ratio: 4 / 3;
      object-fit: cover;
      transition: transform 0.3s ease; /* Add transition for image */
  }

  .dish-card:hover img {
      transform: scale(1.05); /* Scale image on card hover */
  }

  .dish-card h2 {
      font-size: 1.5rem;
      margin: 1rem 0 0.5rem;
      color: #333;
      display: inline-block; /* Make it inline */
  }

  .price {
      font-size: 1.2rem;
      font-weight: 600;
      color: #333;
      margin-left: 1rem; /* Margin for space between title and price */
      display: inline-block; /* Make it inline */
  }

  .dish-card button {
      box-shadow: inset 1px 2px 5px rgba(255, 255, 255, 0.92), 1px 2px 5px rgba(0, 0, 0, 0.51);
      background-color: rgb(0, 0, 0);
      color: white;
      border: none;
      padding: 0.75rem 1.5rem;
      font-size: 1rem;
      border-radius: 6px;
      cursor: pointer;
      margin-bottom: 1.2rem;
      transition: background-color 0.3s ease;
  }

  .dish-card button:hover {
      transform: scale(0.95);
      background-color: rgb(136, 57, 33);
  }

  .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1000; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgba(0, 0, 0, 0.5); /* Black w/ opacity */
  }

  .modal-content {
      background-color: #fff;
      margin: 15% auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 300px; /* Could be more or less, depending on screen size */
      border-radius: 8px;
      text-align: center;
  }

  .close-button {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
  }

  .close-button:hover,
  .close-button:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
  }

  @media (max-width: 400px) {
      .dish-card {
          max-width: 90%;
      }
  }
</style>
`;

// Add styles to head
document.head.innerHTML += mealStyles;

// Add event listeners to each "Add to Order" button
const buttons = document.querySelectorAll('.dish-card button');
const orderCircle = document.getElementById('orderCircle');
const orderCountContainer = document.getElementById('orderCountContainer');
let orderCount = 0;
let currentFoodName = '';
let currentFoodImage = '';

// Modal elements
const modal = document.getElementById('quantityModal');
const closeButton = document.querySelector('.close-button');
const foodNameDisplay = document.getElementById('foodName');
const quantityInput = document.getElementById('quantityInput');
const confirmOrderButton = document.getElementById('confirmOrderButton');
const modalFoodImage = document.getElementById('modalFoodImage');

buttons.forEach(button => {
    button.addEventListener('click', (event) => {
        const card = event.target.closest('.dish-card'); // Get the parent card element
        currentFoodName = card.querySelector('h2').innerText; // Get food name
        currentFoodImage = card.querySelector('img').src; // Get food image
        foodNameDisplay.innerText = currentFoodName; // Display food name in modal
        modalFoodImage.src = currentFoodImage; // Set food image in modal
        modal.style.display = 'block'; // Show the modal
    });
});

// Close modal event
closeButton.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Confirm order button event
confirmOrderButton.addEventListener('click', () => {
    const quantity = parseInt(quantityInput.value);
    orderCount += quantity; // Increment order count by selected quantity
    orderCircle.textContent = orderCount; // Update circle content
    modal.style.display = 'none'; // Close the modal
});

// Intersection Observer for individual card swipe effect
const cards = document.querySelectorAll('.dish-card');
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('show'); // Add class to trigger swipe effect
            observer.unobserve(entry.target); // Stop observing once shown
        }
    });
}, {
    threshold: 0.1 // Trigger when 10% of the card is visible
});

// Observe each card individually
cards.forEach(card => {
    observer.observe(card); // Start observing each card
});

// Scroll event to check if the section is scrolled and adjust circle position
window.addEventListener('scroll', () => {
    const sectionTop = orderCountContainer.getBoundingClientRect().top;
    const sectionVisible = sectionTop < window.innerHeight && sectionTop > 0;

    if (sectionVisible && window.scrollY > 0) {
        orderCountContainer.classList.add('scrolled');
        const viewportHeight = window.innerHeight;
        const circle = document.getElementById('orderCircle');
        circle.style.position = 'fixed';
        circle.style.top = `${(viewportHeight / 2) - 15}px`; // Center the circle vertically
    } else {
        orderCountContainer.classList.remove('scrolled');
        const circle = document.getElementById('orderCircle');
        circle.style.position = 'relative';
        circle.style.top = '0'; // Reset to original position
    }
});

// Close modal when clicking outside the modal content
window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});