// Utility for local storage (fallback or wrapper)
const storage = {
    set(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    },
    get(key) {
        try {
            return JSON.parse(localStorage.getItem(key));
        } catch {
            return null;
        }
    },
    remove(key) {
        localStorage.removeItem(key);
    }
};

// Main Application Controller
class FoodHubApp {
    constructor() {
        this.isInitialized = false;
        this.debugMode = true; // Toggle for production logging
        this.boundEvents = [];
        this.shortcuts = {
            '1': () => navigation.showSection('explore'),
            '2': () => navigation.showSection('meals'),
            '3': () => navigation.showSection('nutrition'),
            '4': () => navigation.showSection('shopping'),
            '5': () => navigation.showSection('recipes'),
            '6': () => navigation.showSection('profile'),
            's': () => this.quickSave(),
        };
    }

    init() {
        if (this.isInitialized) return;

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeApp());
        } else {
            this.initializeApp();
        }
    }

    initializeApp() {
        try {
            this.initializeStorage();
            this.initializeAuth();
            this.initializeNavigation();
            this.initializeModules();
            this.bindGlobalEvents();
            this.showWelcomeMessage();

            this.isInitialized = true;
            this.log('FoodHub application initialized successfully');
        } catch (error) {
            console.error('Error initializing FoodHub application:', error);
            this.showErrorMessage('Failed to initialize application. Please refresh the page.');
        }
    }

    initializeStorage() {
        try {
            storage.set('test', 'test');
            storage.remove('test');
        } catch {
            throw new Error('Local storage not available');
        }
    }

    initializeAuth() {
        if (auth?.isLoggedIn()) {
            this.log(`User is logged in: ${auth.getCurrentUser().name}`);
        }
    }

    initializeNavigation() {
        navigation.showSection('explore');
    }

    initializeModules() {
        const modules = ['foodExplorer', 'mealPlanner', 'nutritionTracker', 'shoppingManager', 'recipeManager', 'profileManager'];
        modules.forEach(mod => {
            if (window[mod]?.init) window[mod].init();
        });
    }

    bindGlobalEvents() {
        const addEvent = (target, type, handler) => {
            target.addEventListener(type, handler);
            this.boundEvents.push(() => target.removeEventListener(type, handler));
        };

        addEvent(document, 'keydown', (e) => this.handleKeyboardShortcuts(e));
        addEvent(window, 'online', () => navigation.showNotification('You are back online!', 'success'));
        addEvent(window, 'offline', () => navigation.showNotification('You are offline. Data will be saved locally.', 'warning'));
        addEvent(document, 'visibilitychange', () => {
            if (!document.hidden) this.refreshDataIfNeeded();
        });
        addEvent(window, 'resize', () => this.handleWindowResize());
        addEvent(window, 'beforeunload', (e) => {
            if (this.hasUnsavedData()) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    }

    unbindGlobalEvents() {
        this.boundEvents.forEach(unbind => unbind());
        this.boundEvents = [];
    }

    handleKeyboardShortcuts(e) {
        if (['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;

        if (e.ctrlKey || e.metaKey) {
            const action = this.shortcuts[e.key.toLowerCase()];
            if (action) {
                e.preventDefault();
                action();
            }
        }

        if (e.key === 'Escape') this.closeAllModals();
    }

    handleWindowResize() {
        const isMobile = window.innerWidth < 768;
        document.body.classList.toggle('mobile-layout', isMobile);
    }

    refreshDataIfNeeded() {
        if (navigation.currentSection === 'nutrition' && window.nutritionTracker) {
            nutritionTracker.updateFromMeals?.();
            nutritionTracker.renderCharts?.();
        }
    }

    hasUnsavedData() {
        return window.mealPlanner?.hasPendingChanges?.() || false;
    }

    quickSave() {
        try {
            navigation.showNotification('All data saved!', 'success');
        } catch {
            navigation.showNotification('Error saving data', 'error');
        }
    }

    closeAllModals() {
        const modals = document.querySelectorAll('.modal.active');
        modals.forEach(modal => modal.classList.remove('active'));
        document.body.style.overflow = '';
    }

    showWelcomeMessage() {
        if (!storage.get('foodhub_has_visited')) {
            setTimeout(() => {
                navigation.showNotification('Welcome to FoodHub! Start by exploring foods or planning your meals.', 'info');
                storage.set('foodhub_has_visited', true);
            }, 1000);
        }
    }

    showErrorMessage(message) {
        const errorOverlay = document.createElement('div');
        errorOverlay.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.8); color: white; display: flex;
            align-items: center; justify-content: center; z-index: 9999;
        `;

        errorOverlay.innerHTML = `
            <div style="text-align: center; padding: 2rem;">
                <h2>⚠️ Application Error</h2>
                <p>${message}</p>
                <button onclick="window.location.reload()" style="
                    background: var(--primary-600); color: white; border: none;
                    padding: 0.75rem 1.5rem; border-radius: 0.5rem; cursor: pointer;
                ">Reload Page</button>
            </div>
        `;

        document.body.appendChild(errorOverlay);
    }

    // Logging helper
    log(...args) {
        if (this.debugMode) {
            console.log('[FoodHub]', ...args);
        }
    }

    // Static utilities
    static formatDate(date) {
        return new Date(date).toLocaleDateString();
    }

    static formatTime(date) {
        return new Date(date).toLocaleTimeString();
    }

    static formatDateTime(date) {
        return new Date(date).toLocaleString();
    }

    static generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    static debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    static throttle(func, limit) {
        let inThrottle;
        return function (...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    measurePerformance(name, fn) {
        const start = performance.now();
        const result = fn();
        const end = performance.now();
        this.log(`${name} took ${end - start} ms`);
        return result;
    }

    validateData(data, schema) {
        for (const [key, rules] of Object.entries(schema)) {
            const value = data[key];
            if (rules.required && (value === undefined || value === null || value === '')) {
                throw new Error(`${key} is required`);
            }
            if (value !== undefined && rules.type && typeof value !== rules.type) {
                throw new Error(`${key} must be of type ${rules.type}`);
            }
            if (rules.min !== undefined && value < rules.min) {
                throw new Error(`${key} must be at least ${rules.min}`);
            }
            if (rules.max !== undefined && value > rules.max) {
                throw new Error(`${key} must be at most ${rules.max}`);
            }
        }
        return true;
    }
}

// Create and initialize the application
const app = new FoodHubApp();
app.init();
window.FoodHubApp = app;
