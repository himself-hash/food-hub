// Authentication System (Client-side simulation)
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        // Check if user is already logged in
        const savedUser = storage.getUser();
        if (savedUser) {
            this.currentUser = savedUser;
            this.updateUI();
        }
    }

    // Register new user
    register(userData) {
        const { name, email, password, confirmPassword } = userData;

        // Validation
        if (!name || !email || !password || !confirmPassword) {
            throw new Error('All fields are required');
        }

        if (password !== confirmPassword) {
            throw new Error('Passwords do not match');
        }

        if (password.length < 6) {
            throw new Error('Password must be at least 6 characters long');
        }

        if (!this.isValidEmail(email)) {
            throw new Error('Please enter a valid email address');
        }

        // Check if user already exists
        const existingUsers = storage.getUsers();
        if (existingUsers.find(user => user.email === email)) {
            throw new Error('User with this email already exists');
        }

        // Create new user
        const newUser = {
            id: this.generateUserId(),
            name: name.trim(),
            email: email.toLowerCase().trim(),
            password: this.hashPassword(password), // In real app, use proper hashing
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
        };

        // Save user
        existingUsers.push(newUser);
        storage.saveUsers(existingUsers);

        // Log in the new user
        this.currentUser = { ...newUser };
        delete this.currentUser.password; // Don't store password in current user
        storage.saveUser(this.currentUser);
        
        this.updateUI();
        return this.currentUser;
    }

    // Login user
    login(email, password) {
        if (!email || !password) {
            throw new Error('Email and password are required');
        }

        const users = storage.getUsers();
        const user = users.find(u => u.email === email.toLowerCase().trim());

        if (!user) {
            throw new Error('User not found');
        }

        if (user.password !== this.hashPassword(password)) {
            throw new Error('Invalid password');
        }

        // Update last login
        user.lastLogin = new Date().toISOString();
        storage.saveUsers(users);

        // Set current user
        this.currentUser = { ...user };
        delete this.currentUser.password;
        storage.saveUser(this.currentUser);

        this.updateUI();
        return this.currentUser;
    }

    // Logout user
    logout() {
        this.currentUser = null;
        storage.removeUser();
        this.updateUI();
    }

    // Get current user
    getCurrentUser() {
        return this.currentUser;
    }

    // Check if user is logged in
    isLoggedIn() {
        return this.currentUser !== null;
    }

    // Password reset (simulated)
    resetPassword(email) {
        if (!email) {
            throw new Error('Email is required');
        }

        const users = storage.getUsers();
        const user = users.find(u => u.email === email.toLowerCase().trim());

        if (!user) {
            throw new Error('User not found');
        }

        // In a real app, this would send an email
        // For simulation, we'll just show a success message
        return {
            success: true,
            message: 'Password reset instructions have been sent to your email (simulated)'
        };
    }

    // Update user profile
    updateProfile(updates) {
        if (!this.currentUser) {
            throw new Error('No user logged in');
        }

        const users = storage.getUsers();
        const userIndex = users.findIndex(u => u.id === this.currentUser.id);

        if (userIndex === -1) {
            throw new Error('User not found');
        }

        // Update user data
        const updatedUser = { ...users[userIndex], ...updates };
        users[userIndex] = updatedUser;
        storage.saveUsers(users);

        // Update current user
        this.currentUser = { ...updatedUser };
        delete this.currentUser.password;
        storage.saveUser(this.currentUser);

        this.updateUI();
        return this.currentUser;
    }

    // Change password
    changePassword(currentPassword, newPassword) {
        if (!this.currentUser) {
            throw new Error('No user logged in');
        }

        const users = storage.getUsers();
        const user = users.find(u => u.id === this.currentUser.id);

        if (!user) {
            throw new Error('User not found');
        }

        if (user.password !== this.hashPassword(currentPassword)) {
            throw new Error('Current password is incorrect');
        }

        if (newPassword.length < 6) {
            throw new Error('New password must be at least 6 characters long');
        }

        // Update password
        user.password = this.hashPassword(newPassword);
        storage.saveUsers(users);

        return { success: true, message: 'Password updated successfully' };
    }

    // Helper methods
    generateUserId() {
        return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    hashPassword(password) {
        // Simple hash for demo purposes - use proper hashing in production
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash.toString();
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    updateUI() {
        const navAuth = document.getElementById('nav-auth');
        const navUser = document.getElementById('nav-user');
        const userName = document.getElementById('user-name');

        if (this.currentUser) {
            navAuth.classList.add('hidden');
            navUser.classList.remove('hidden');
            if (userName) {
                userName.textContent = `Welcome, ${this.currentUser.name}!`;
            }
        } else {
            navAuth.classList.remove('hidden');
            navUser.classList.add('hidden');
        }
    }
}

// Create global auth instance
const auth = new AuthManager();