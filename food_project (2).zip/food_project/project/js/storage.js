// Local Storage Management
class StorageManager {
    constructor() {
        this.keys = {
            USER: 'foodhub_user',
            USERS: 'foodhub_users',
            MEALS: 'foodhub_meals',
            PREFERENCES: 'foodhub_preferences',
            GOALS: 'foodhub_goals',
            RECIPES: 'foodhub_recipes',
            SHOPPING_LIST: 'foodhub_shopping'
        };
    }

    // Generic storage methods
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error('Error saving to localStorage:', error);
            return false;
        }
    }

    get(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Error reading from localStorage:', error);
            return defaultValue;
        }
    }

    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Error removing from localStorage:', error);
            return false;
        }
    }

    clear() {
        try {
            localStorage.clear();
            return true;
        } catch (error) {
            console.error('Error clearing localStorage:', error);
            return false;
        }
    }

    // User management
    saveUser(user) {
        return this.set(this.keys.USER, user);
    }

    getUser() {
        return this.get(this.keys.USER);
    }

    removeUser() {
        return this.remove(this.keys.USER);
    }

    saveUsers(users) {
        return this.set(this.keys.USERS, users);
    }

    getUsers() {
        return this.get(this.keys.USERS, []);
    }

    // Meal planning
    saveMeals(meals) {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.MEALS}_${user.id}`;
            return this.set(key, meals);
        }
        return this.set(this.keys.MEALS, meals);
    }

    getMeals() {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.MEALS}_${user.id}`;
            return this.get(key, { breakfast: [], lunch: [], dinner: [], snacks: [] });
        }
        return this.get(this.keys.MEALS, { breakfast: [], lunch: [], dinner: [], snacks: [] });
    }

    // Dietary preferences
    savePreferences(preferences) {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.PREFERENCES}_${user.id}`;
            return this.set(key, preferences);
        }
        return this.set(this.keys.PREFERENCES, preferences);
    }

    getPreferences() {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.PREFERENCES}_${user.id}`;
            return this.get(key, []);
        }
        return this.get(this.keys.PREFERENCES, []);
    }

    // Nutrition goals
    saveGoals(goals) {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.GOALS}_${user.id}`;
            return this.set(key, goals);
        }
        return this.set(this.keys.GOALS, goals);
    }

    getGoals() {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.GOALS}_${user.id}`;
            return this.get(key, DEFAULT_NUTRITION_GOALS);
        }
        return this.get(this.keys.GOALS, DEFAULT_NUTRITION_GOALS);
    }

    // Recipes
    saveRecipes(recipes) {
        return this.set(this.keys.RECIPES, recipes);
    }

    getRecipes() {
        return this.get(this.keys.RECIPES, SAMPLE_RECIPES);
    }

    // Shopping list
    saveShoppingList(list) {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.SHOPPING_LIST}_${user.id}`;
            return this.set(key, list);
        }
        return this.set(this.keys.SHOPPING_LIST, list);
    }

    getShoppingList() {
        const user = this.getUser();
        if (user) {
            const key = `${this.keys.SHOPPING_LIST}_${user.id}`;
            return this.get(key, []);
        }
        return this.get(this.keys.SHOPPING_LIST, []);
    }

    // Data export/import
    exportData() {
        const data = {
            user: this.getUser(),
            meals: this.getMeals(),
            preferences: this.getPreferences(),
            goals: this.getGoals(),
            recipes: this.getRecipes(),
            shoppingList: this.getShoppingList(),
            exportDate: new Date().toISOString()
        };
        return JSON.stringify(data, null, 2);
    }

    importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            
            if (data.user) this.saveUser(data.user);
            if (data.meals) this.saveMeals(data.meals);
            if (data.preferences) this.savePreferences(data.preferences);
            if (data.goals) this.saveGoals(data.goals);
            if (data.recipes) this.saveRecipes(data.recipes);
            if (data.shoppingList) this.saveShoppingList(data.shoppingList);
            
            return true;
        } catch (error) {
            console.error('Error importing data:', error);
            return false;
        }
    }

    // Storage size calculation
    getStorageSize() {
        let total = 0;
        for (let key in localStorage) {
            if (localStorage.hasOwnProperty(key)) {
                total += localStorage[key].length + key.length;
            }
        }
        return total;
    }

    getStorageSizeFormatted() {
        const bytes = this.getStorageSize();
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        if (bytes === 0) return '0 Bytes';
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
    }
}

// Create global storage instance
const storage = new StorageManager();