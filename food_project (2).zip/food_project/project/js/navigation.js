// Navigation Management
class NavigationManager {
    constructor() {
        this.currentSection = 'explore';
        this.init();
    }

    init() {
        this.bindEvents();
        this.showSection(this.currentSection);
    }

    bindEvents() {
        // Navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                this.showSection(section);
            });
        });

        // Mobile menu toggle
        const navToggle = document.getElementById('nav-toggle');
        const navMenu = document.getElementById('nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
            });
        }

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => {
            if (navMenu && !navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('active');
            }
        });

        // Auth buttons
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const logoutBtn = document.getElementById('logout-btn');

        if (loginBtn) {
            loginBtn.addEventListener('click', () => this.showModal('login-modal'));
        }

        if (registerBtn) {
            registerBtn.addEventListener('click', () => this.showModal('register-modal'));
        }

        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                auth.logout();
                this.showSection('explore');
            });
        }

        // Modal management
        this.initModals();
    }

    showSection(sectionName) {
        // Hide all sections
        const sections = document.querySelectorAll('.section');
        sections.forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(`${sectionName}-section`);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionName;
        }

        // Update navigation
        this.updateNavigation(sectionName);

        // Close mobile menu
        const navMenu = document.getElementById('nav-menu');
        if (navMenu) {
            navMenu.classList.remove('active');
        }

        // Trigger section-specific initialization
        this.initializeSection(sectionName);
    }

    updateNavigation(activeSection) {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-section') === activeSection) {
                link.classList.add('active');
            }
        });
    }

    initializeSection(sectionName) {
        switch (sectionName) {
            case 'explore':
                if (window.foodExplorer) {
                    foodExplorer.init();
                }
                break;
            case 'meals':
                if (window.mealPlanner) {
                    mealPlanner.init();
                }
                break;
            case 'nutrition':
                if (window.nutritionTracker) {
                    nutritionTracker.init();
                }
                break;
            case 'shopping':
                if (window.shoppingManager) {
                    shoppingManager.init();
                }
                break;
            case 'recipes':
                if (window.recipeManager) {
                    recipeManager.init();
                }
                break;
            case 'profile':
                if (window.profileManager) {
                    profileManager.init();
                }
                break;
        }
    }

    initModals() {
        // Modal close buttons
        const modalCloses = document.querySelectorAll('.modal-close');
        modalCloses.forEach(close => {
            close.addEventListener('click', (e) => {
                const modal = close.closest('.modal');
                if (modal) {
                    this.hideModal(modal.id);
                }
            });
        });

        // Close modal when clicking outside
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideModal(modal.id);
                }
            });
        });

        // Form submissions
        this.initAuthForms();
    }

    initAuthForms() {
        // Login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // Register form
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRegister();
            });
        }

        // Show register modal from login
        const showRegister = document.getElementById('show-register');
        if (showRegister) {
            showRegister.addEventListener('click', (e) => {
                e.preventDefault();
                this.hideModal('login-modal');
                this.showModal('register-modal');
            });
        }

        // Show login modal from register
        const showLogin = document.getElementById('show-login');
        if (showLogin) {
            showLogin.addEventListener('click', (e) => {
                e.preventDefault();
                this.hideModal('register-modal');
                this.showModal('login-modal');
            });
        }

        // Forgot password
        const forgotPassword = document.getElementById('forgot-password');
        if (forgotPassword) {
            forgotPassword.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleForgotPassword();
            });
        }
    }

    handleLogin() {
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        try {
            auth.login(email, password);
            this.hideModal('login-modal');
            this.showNotification('Login successful!', 'success');
            
            // Reset form
            document.getElementById('login-form').reset();
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    handleRegister() {
        const name = document.getElementById('register-name').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('register-confirm').value;

        try {
            auth.register({ name, email, password, confirmPassword });
            this.hideModal('register-modal');
            this.showNotification('Registration successful! Welcome to FoodHub!', 'success');
            
            // Reset form
            document.getElementById('register-form').reset();
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    handleForgotPassword() {
        const email = document.getElementById('login-email').value;
        
        if (!email) {
            this.showNotification('Please enter your email address first', 'warning');
            return;
        }

        try {
            const result = auth.resetPassword(email);
            this.showNotification(result.message, 'success');
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span>${message}</span>
            <button class="notification-close">&times;</button>
        `;

        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: ${type === 'success' ? 'var(--success-500)' : 
                        type === 'error' ? 'var(--error-500)' : 
                        type === 'warning' ? 'var(--warning-500)' : 'var(--primary-500)'};
            color: white;
            padding: var(--space-4) var(--space-6);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            z-index: 3000;
            display: flex;
            align-items: center;
            gap: var(--space-4);
            max-width: 400px;
            animation: slideIn 0.3s ease-out;
        `;

        // Add to page
        document.body.appendChild(notification);

        // Close button
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.style.cssText = `
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0;
            margin-left: auto;
        `;

        closeBtn.addEventListener('click', () => {
            this.hideNotification(notification);
        });

        // Auto-hide after 5 seconds
        setTimeout(() => {
            this.hideNotification(notification);
        }, 5000);
    }

    hideNotification(notification) {
        if (notification && notification.parentNode) {
            notification.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }
}

// Create global navigation instance
const navigation = new NavigationManager();