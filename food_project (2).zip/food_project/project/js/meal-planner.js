// Meal Planner Module
class MealPlanner {
    constructor() {
        this.meals = {
            breakfast: [],
            lunch: [],
            dinner: [],
            snacks: []
        };
        this.currentMeal = 'breakfast';
    }

    init() {
        this.loadMeals();
        this.bindEvents();
        this.renderMeals();
        this.updateDailySummary();
    }

    loadMeals() {
        this.meals = storage.getMeals();
    }
loadMeals() {
    const savedMeals = storage.getMeals();
    const isEmpty = Object.values(savedMeals).every(meal => !meal || meal.length === 0);

    if (isEmpty) {
        // Provide demo data
        this.meals = {
            breakfast: [
                {
                    id: 1,
                    name: 'Oatmeal with Banana',
                    emoji: '🍌',
                    nutrition: {
                        calories: 250,
                        protein: 5,
                        carbs: 45,
                        fat: 4,
                        fiber: 6,
                        sugar: 14
                    },
                    addedAt: new Date().toISOString(),
                    quantity: 1
                }
            ],
            lunch: [
                {
                    id: 2,
                    name: 'Grilled Chicken Salad',
                    emoji: '🥗',
                    nutrition: {
                        calories: 350,
                        protein: 30,
                        carbs: 10,
                        fat: 20,
                        fiber: 5,
                        sugar: 3
                    },
                    addedAt: new Date().toISOString(),
                    quantity: 1
                }
            ],
            dinner: [
                {
                    id: 3,
                    name: 'Spaghetti Bolognese',
                    emoji: '🍝',
                    nutrition: {
                        calories: 500,
                        protein: 25,
                        carbs: 60,
                        fat: 15,
                        fiber: 4,
                        sugar: 8
                    },
                    addedAt: new Date().toISOString(),
                    quantity: 1
                }
            ],
            snacks: [
                {
                    id: 4,
                    name: 'Greek Yogurt',
                    emoji: '🥣',
                    nutrition: {
                        calories: 100,
                        protein: 10,
                        carbs: 8,
                        fat: 2,
                        fiber: 0,
                        sugar: 6
                    },
                    addedAt: new Date().toISOString(),
                    quantity: 1
                }
            ]
        };

        storage.saveMeals(this.meals);
    } else {
        this.meals = savedMeals;
    }
}

    bindEvents() {
        // Meal tabs
        const mealTabs = document.querySelectorAll('.meal-tab');
        mealTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const mealType = tab.getAttribute('data-meal');
                this.switchMeal(mealType);
            });
        });

        // Add food buttons
        const addFoodBtns = document.querySelectorAll('.add-food-btn');
        addFoodBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const mealType = btn.getAttribute('data-meal');
                this.showAddFoodModal(mealType);
            });
        });

        // Modal food search
        const modalSearch = document.getElementById('modal-food-search');
        if (modalSearch) {
            modalSearch.addEventListener('input', (e) => {
                this.filterModalFoods(e.target.value);
            });
        }
    }

    switchMeal(mealType) {
        // Update tabs
        const tabs = document.querySelectorAll('.meal-tab');
        tabs.forEach(tab => {
            tab.classList.remove('active');
            if (tab.getAttribute('data-meal') === mealType) {
                tab.classList.add('active');
            }
        });

        // Update panels
        const panels = document.querySelectorAll('.meal-panel');
        panels.forEach(panel => {
            panel.classList.remove('active');
        });

        const targetPanel = document.getElementById(`${mealType}-panel`);
        if (targetPanel) {
            targetPanel.classList.add('active');
        }

        this.currentMeal = mealType;
        this.renderMealFoods(mealType);
    }

    renderMeals() {
        ['breakfast', 'lunch', 'dinner', 'snacks'].forEach(mealType => {
            this.renderMealFoods(mealType);
        });
    }

    renderMealFoods(mealType) {
        const container = document.getElementById(`${mealType}-foods`);
        if (!container) return;

        const mealFoods = this.meals[mealType] || [];

        if (mealFoods.length === 0) {
            container.innerHTML = `
                <div class="empty-meal">
                    <p>No foods added to ${mealType} yet.</p>
                    <p>Click "Add Food" to get started!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = mealFoods.map((food, index) => this.createMealFoodItem(food, mealType, index)).join('');

        // Add remove event listeners
        const removeButtons = container.querySelectorAll('.meal-food-remove');
        removeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const mealType = btn.getAttribute('data-meal');
                const index = parseInt(btn.getAttribute('data-index'));
                this.removeFoodFromMeal(mealType, index);
            });
        });
    }

    createMealFoodItem(food, mealType, index) {
        return `
            <div class="meal-food-item">
                <div class="meal-food-info">
                    <div class="meal-food-name">${food.emoji} ${food.name}</div>
                    <div class="meal-food-nutrition">
                        ${food.nutrition.calories} cal • ${food.nutrition.protein}g protein • ${food.nutrition.carbs}g carbs • ${food.nutrition.fat}g fat
                    </div>
                </div>
                <button class="meal-food-remove" data-meal="${mealType}" data-index="${index}">
                    ✕
                </button>
            </div>
        `;
    }

    showAddFoodModal(mealType) {
        this.currentMealForAdding = mealType;
        
        // Populate modal with foods
        this.renderModalFoods();
        
        // Show modal
        navigation.showModal('add-food-modal');
    }

    renderModalFoods(searchTerm = '') {
        const container = document.getElementById('modal-food-grid');
        if (!container) return;

        let foods = FOOD_DATABASE;

        // Filter by search term
        if (searchTerm) {
            foods = foods.filter(food => 
                food.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                food.category.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Apply dietary preferences
        const userPreferences = storage.getPreferences();
        if (userPreferences.length > 0) {
            foods = foods.filter(food => {
                return userPreferences.every(pref => food.dietaryInfo[pref] === true);
            });
        }

        container.innerHTML = foods.map(food => this.createModalFoodCard(food)).join('');

        // Add click events
        const foodCards = container.querySelectorAll('.food-card');
        foodCards.forEach(card => {
            card.addEventListener('click', () => {
                const foodId = parseInt(card.dataset.foodId);
                this.addFoodToCurrentMeal(foodId);
            });
        });
    }

    createModalFoodCard(food) {
        return `
            <div class="food-card" data-food-id="${food.id}">
                <div class="food-card-image">
                    ${food.emoji}
                </div>
                <div class="food-card-content">
                    <h4 class="food-card-title">${food.name}</h4>
                    <div class="food-card-nutrition">
                        <div class="nutrition-item">
                            <span>Cal</span>
                            <span>${food.nutrition.calories}</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Protein</span>
                            <span>${food.nutrition.protein}g</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    filterModalFoods(searchTerm) {
        this.renderModalFoods(searchTerm);
    }

    addFoodToCurrentMeal(foodId) {
        const food = FOOD_DATABASE.find(f => f.id === foodId);
        if (!food || !this.currentMealForAdding) return;

        // Add food to meal
        if (!this.meals[this.currentMealForAdding]) {
            this.meals[this.currentMealForAdding] = [];
        }

        this.meals[this.currentMealForAdding].push({
            ...food,
            addedAt: new Date().toISOString(),
            quantity: 1
        });

        // Save meals
        storage.saveMeals(this.meals);

        // Update UI
        this.renderMealFoods(this.currentMealForAdding);
        this.updateDailySummary();

        // Close modal
        navigation.hideModal('add-food-modal');

        // Show success message
        navigation.showNotification(`${food.name} added to ${this.currentMealForAdding}!`, 'success');
    }

    removeFoodFromMeal(mealType, index) {
        if (!this.meals[mealType] || !this.meals[mealType][index]) return;

        const food = this.meals[mealType][index];
        
        // Remove food
        this.meals[mealType].splice(index, 1);

        // Save meals
        storage.saveMeals(this.meals);

        // Update UI
        this.renderMealFoods(mealType);
        this.updateDailySummary();

        // Show success message
        navigation.showNotification(`${food.name} removed from ${mealType}`, 'success');
    }

    updateDailySummary() {
        const totals = this.calculateDailyTotals();

        // Update summary display
        const caloriesEl = document.getElementById('total-calories');
        const proteinEl = document.getElementById('total-protein');
        const carbsEl = document.getElementById('total-carbs');
        const fatEl = document.getElementById('total-fat');

        if (caloriesEl) calories.textContent = Math.round(totals.calories);
        if (proteinEl) proteinEl.textContent = `${Math.round(totals.protein)}g`;
        if (carbsEl) carbsEl.textContent = `${Math.round(totals.carbs)}g`;
        if (fatEl) fatEl.textContent = `${Math.round(totals.fat)}g`;

        // Update nutrition tracker if it exists
        if (window.nutritionTracker) {
            nutritionTracker.updateCharts(totals);
        }
    }

    calculateDailyTotals() {
        const totals = {
            calories: 0,
            protein: 0,
            carbs: 0,
            fat: 0,
            fiber: 0,
            sugar: 0
        };

        Object.values(this.meals).forEach(meal => {
            meal.forEach(food => {
                totals.calories += food.nutrition.calories || 0;
                totals.protein += food.nutrition.protein || 0;
                totals.carbs += food.nutrition.carbs || 0;
                totals.fat += food.nutrition.fat || 0;
                totals.fiber += food.nutrition.fiber || 0;
                totals.sugar += food.nutrition.sugar || 0;
            });
        });

        return totals;
    }

    clearMeal(mealType) {
        if (!confirm(`Are you sure you want to clear all foods from ${mealType}?`)) {
            return;
        }

        this.meals[mealType] = [];
        storage.saveMeals(this.meals);
        this.renderMealFoods(mealType);
        this.updateDailySummary();

        navigation.showNotification(`${mealType} cleared`, 'success');
    }

    clearAllMeals() {
        if (!confirm('Are you sure you want to clear all meals for today?')) {
            return;
        }

        this.meals = {
            breakfast: [],
            lunch: [],
            dinner: [],
            snacks: []
        };

        storage.saveMeals(this.meals);
        this.renderMeals();
        this.updateDailySummary();

        navigation.showNotification('All meals cleared', 'success');
    }

    exportMealPlan() {
        const mealPlan = {
            date: new Date().toISOString().split('T')[0],
            meals: this.meals,
            totals: this.calculateDailyTotals()
        };

        const dataStr = JSON.stringify(mealPlan, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `meal-plan-${mealPlan.date}.json`;
        link.click();

        URL.revokeObjectURL(url);
        navigation.showNotification('Meal plan exported!', 'success');
    }

    // Get all foods from all meals (utility method)
    getAllMealFoods() {
        const allFoods = [];
        Object.values(this.meals).forEach(meal => {
            allFoods.push(...meal);
        });
        return allFoods;
    }
}

// Create global meal planner instance
const mealPlanner = new MealPlanner();