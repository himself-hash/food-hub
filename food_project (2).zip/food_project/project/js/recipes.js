// Recipe Manager
class RecipeManager {
    constructor() {
        this.recipes = [];
    }

    init() {
        this.loadRecipes();
        this.bindEvents();
        this.renderRecipes();
    }

    loadRecipes() {
        this.recipes = storage.getRecipes();
    }

    bindEvents() {
        // Add recipe button
        const addRecipeBtn = document.getElementById('add-recipe-btn');
        if (addRecipeBtn) {
            addRecipeBtn.addEventListener('click', () => {
                this.showAddRecipeModal();
            });
        }

        // Recipe form submission
        const recipeForm = document.getElementById('recipe-form');
        if (recipeForm) {
            recipeForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRecipeSubmission();
            });
        }
    }

    showAddRecipeModal() {
        navigation.showModal('add-recipe-modal');
    }

    handleRecipeSubmission() {
        const name = document.getElementById('recipe-name').value.trim();
        const ingredients = document.getElementById('recipe-ingredients').value.trim();
        const instructions = document.getElementById('recipe-instructions').value.trim();
        const servings = parseInt(document.getElementById('recipe-servings').value);

        if (!name || !ingredients || !instructions || !servings) {
            navigation.showNotification('Please fill in all fields', 'error');
            return;
        }

        const newRecipe = {
            id: Date.now(),
            name: name,
            ingredients: ingredients.split('\n').filter(line => line.trim()),
            instructions: instructions,
            servings: servings,
            rating: 0,
            author: auth.getCurrentUser()?.name || 'Anonymous',
            dateAdded: new Date().toISOString(),
            ratings: []
        };

        this.recipes.push(newRecipe);
        storage.saveRecipes(this.recipes);
        this.renderRecipes();

        // Close modal and reset form
        navigation.hideModal('add-recipe-modal');
        document.getElementById('recipe-form').reset();

        navigation.showNotification('Recipe added successfully!', 'success');
    }

    renderRecipes() {
        const container = document.getElementById('recipes-grid');
        if (!container) return;

        if (this.recipes.length === 0) {
            container.innerHTML = `
                <div class="empty-recipes">
                    <h3>No recipes yet</h3>
                    <p>Start building your recipe collection by adding your first recipe!</p>
                    <button class="btn btn-primary" onclick="recipeManager.showAddRecipeModal()">Add Your First Recipe</button>
                </div>
            `;
            return;
        }

        container.innerHTML = this.recipes.map(recipe => this.createRecipeCard(recipe)).join('');

        // Bind rating events
        this.bindRatingEvents();
    }

    createRecipeCard(recipe) {
        const averageRating = this.calculateAverageRating(recipe);
        const ratingStars = this.generateStarRating(averageRating, recipe.id);

        return `
            <div class="recipe-card" data-recipe-id="${recipe.id}">
                <div class="recipe-card-header">
                    <h3 class="recipe-card-title">${recipe.name}</h3>
                    <div class="recipe-card-meta">
                        <span>Serves ${recipe.servings}</span>
                        <div class="recipe-rating" data-recipe-id="${recipe.id}">
                            ${ratingStars}
                        </div>
                    </div>
                </div>
                
                <div class="recipe-card-body">
                    <div class="recipe-ingredients">
                        <h4>Ingredients:</h4>
                        <ul>
                            ${recipe.ingredients.slice(0, 5).map(ingredient => `<li>${ingredient}</li>`).join('')}
                            ${recipe.ingredients.length > 5 ? `<li><em>...and ${recipe.ingredients.length - 5} more</em></li>` : ''}
                        </ul>
                    </div>
                    
                    <div class="recipe-instructions">
                        <p>${recipe.instructions.substring(0, 150)}${recipe.instructions.length > 150 ? '...' : ''}</p>
                    </div>
                </div>
                
                <div class="recipe-card-footer">
                    <small>By ${recipe.author} • ${this.formatDate(recipe.dateAdded)}</small>
                    <div class="recipe-actions">
                        <button class="btn btn-outline btn-sm" onclick="recipeManager.viewRecipe(${recipe.id})">View Full Recipe</button>
                        <button class="btn btn-outline btn-sm" onclick="recipeManager.deleteRecipe(${recipe.id})">Delete</button>
                    </div>
                </div>
            </div>
        `;
    }

    generateStarRating(rating, recipeId) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            const filled = i <= rating ? 'filled' : '';
            stars += `<span class="star ${filled}" data-rating="${i}" data-recipe-id="${recipeId}">★</span>`;
        }
        return stars;
    }

    calculateAverageRating(recipe) {
        if (!recipe.ratings || recipe.ratings.length === 0) {
            return 0;
        }
        const sum = recipe.ratings.reduce((acc, rating) => acc + rating, 0);
        return Math.round(sum / recipe.ratings.length);
    }

    bindRatingEvents() {
        const stars = document.querySelectorAll('.star');
        stars.forEach(star => {
            star.addEventListener('click', () => {
                const rating = parseInt(star.getAttribute('data-rating'));
                const recipeId = parseInt(star.getAttribute('data-recipe-id'));
                this.rateRecipe(recipeId, rating);
            });

            star.addEventListener('mouseenter', () => {
                const rating = parseInt(star.getAttribute('data-rating'));
                const recipeId = parseInt(star.getAttribute('data-recipe-id'));
                this.highlightStars(recipeId, rating);
            });
        });

        // Reset star highlighting on mouse leave
        const ratingContainers = document.querySelectorAll('.recipe-rating');
        ratingContainers.forEach(container => {
            container.addEventListener('mouseleave', () => {
                const recipeId = parseInt(container.getAttribute('data-recipe-id'));
                const recipe = this.recipes.find(r => r.id === recipeId);
                const currentRating = this.calculateAverageRating(recipe);
                this.highlightStars(recipeId, currentRating);
            });
        });
    }

    highlightStars(recipeId, rating) {
        const stars = document.querySelectorAll(`[data-recipe-id="${recipeId}"] .star`);
        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.add('filled');
            } else {
                star.classList.remove('filled');
            }
        });
    }

    rateRecipe(recipeId, rating) {
        const recipe = this.recipes.find(r => r.id === recipeId);
        if (!recipe) return;

        // Add rating to recipe
        if (!recipe.ratings) {
            recipe.ratings = [];
        }
        recipe.ratings.push(rating);

        // Save recipes
        storage.saveRecipes(this.recipes);

        // Update display
        const newAverage = this.calculateAverageRating(recipe);
        this.highlightStars(recipeId, newAverage);

        navigation.showNotification(`Rated "${recipe.name}" ${rating} stars!`, 'success');
    }

    viewRecipe(recipeId) {
        const recipe = this.recipes.find(r => r.id === recipeId);
        if (!recipe) return;

        const modalContent = `
            <div class="recipe-details">
                <div class="recipe-details-header">
                    <h2>${recipe.name}</h2>
                    <div class="recipe-meta">
                        <span>Serves ${recipe.servings}</span>
                        <span>By ${recipe.author}</span>
                        <span>${this.formatDate(recipe.dateAdded)}</span>
                    </div>
                </div>
                
                <div class="recipe-details-ingredients">
                    <h3>Ingredients:</h3>
                    <ul>
                        ${recipe.ingredients.map(ingredient => `<li>${ingredient}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="recipe-details-instructions">
                    <h3>Instructions:</h3>
                    <div class="instructions-text">
                        ${recipe.instructions.replace(/\n/g, '<br>')}
                    </div>
                </div>
                
                <div class="recipe-details-actions">
                    <button class="btn btn-primary" onclick="recipeManager.addRecipeToMealPlan(${recipeId})">Add to Meal Plan</button>
                    <button class="btn btn-outline" onclick="recipeManager.exportRecipe(${recipeId})">Export Recipe</button>
                </div>
            </div>
        `;

        if (window.foodExplorer) {
            foodExplorer.showCustomModal('Recipe Details', modalContent);
        }
    }

    addRecipeToMealPlan(recipeId) {
        const recipe = this.recipes.find(r => r.id === recipeId);
        if (!recipe) return;

        // For now, just show a notification
        // In a more advanced version, you could parse ingredients and add them to meals
        navigation.showNotification(`Recipe "${recipe.name}" noted for meal planning!`, 'info');
        
        if (window.foodExplorer) {
            foodExplorer.hideCustomModal();
        }
    }

    exportRecipe(recipeId) {
        const recipe = this.recipes.find(r => r.id === recipeId);
        if (!recipe) return;

        const recipeText = this.formatRecipeForExport(recipe);
        const dataBlob = new Blob([recipeText], { type: 'text/plain' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `${recipe.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
        link.click();

        URL.revokeObjectURL(url);
        navigation.showNotification('Recipe exported!', 'success');
    }

    formatRecipeForExport(recipe) {
        let text = `${recipe.name}\n`;
        text += '='.repeat(recipe.name.length) + '\n\n';
        text += `Serves: ${recipe.servings}\n`;
        text += `Author: ${recipe.author}\n`;
        text += `Date Added: ${this.formatDate(recipe.dateAdded)}\n\n`;
        
        text += 'INGREDIENTS:\n';
        text += '-'.repeat(12) + '\n';
        recipe.ingredients.forEach(ingredient => {
            text += `• ${ingredient}\n`;
        });
        
        text += '\nINSTRUCTIONS:\n';
        text += '-'.repeat(12) + '\n';
        text += recipe.instructions + '\n\n';
        
        text += 'Created with FoodHub - Your Complete Food Companion';
        
        return text;
    }

    deleteRecipe(recipeId) {
        const recipe = this.recipes.find(r => r.id === recipeId);
        if (!recipe) return;

        if (!confirm(`Are you sure you want to delete "${recipe.name}"?`)) {
            return;
        }

        this.recipes = this.recipes.filter(r => r.id !== recipeId);
        storage.saveRecipes(this.recipes);
        this.renderRecipes();

        navigation.showNotification(`Recipe "${recipe.name}" deleted`, 'success');
    }

    searchRecipes(searchTerm) {
        const filtered = this.recipes.filter(recipe => 
            recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            recipe.ingredients.some(ingredient => 
                ingredient.toLowerCase().includes(searchTerm.toLowerCase())
            ) ||
            recipe.instructions.toLowerCase().includes(searchTerm.toLowerCase())
        );

        return filtered;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString();
    }

    // Import recipes from JSON
    importRecipes(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            if (Array.isArray(data)) {
                // Add imported recipes
                data.forEach(recipe => {
                    recipe.id = Date.now() + Math.random();
                    recipe.dateAdded = new Date().toISOString();
                    recipe.author = auth.getCurrentUser()?.name || 'Imported';
                });
                
                this.recipes.push(...data);
                storage.saveRecipes(this.recipes);
                this.renderRecipes();
                
                navigation.showNotification(`Imported ${data.length} recipes!`, 'success');
            }
        } catch (error) {
            navigation.showNotification('Error importing recipes', 'error');
        }
    }

    // Export all recipes
    exportAllRecipes() {
        const data = {
            recipes: this.recipes,
            exportDate: new Date().toISOString(),
            totalRecipes: this.recipes.length
        };

        const dataStr = JSON.stringify(data, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `all-recipes-${new Date().toISOString().split('T')[0]}.json`;
        link.click();

        URL.revokeObjectURL(url);
        navigation.showNotification('All recipes exported!', 'success');
    }
}

// Create global recipe manager instance
const recipeManager = new RecipeManager();