// Food Database
const FOOD_DATABASE = [
    // Fruits
    {
        id: 1,
        name: "Apple",
        category: "fruits",
        emoji: "🍎",
        nutrition: {
            calories: 52,
            protein: 0.3,
            carbs: 14,
            fat: 0.2,
            fiber: 2.4,
            sugar: 10,
            vitamins: ["C", "K"],
            minerals: ["Potassium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: true
        }
    },
    {
        id: 2,
        name: "Banana",
        category: "fruits",
        emoji: "🍌",
        nutrition: {
            calories: 89,
            protein: 1.1,
            carbs: 23,
            fat: 0.3,
            fiber: 2.6,
            sugar: 12,
            vitamins: ["B6", "C"],
            minerals: ["Potassium", "Magnesium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: true
        }
    },
    {
        id: 3,
        name: "Orange",
        category: "fruits",
        emoji: "🍊",
        nutrition: {
            calories: 47,
            protein: 0.9,
            carbs: 12,
            fat: 0.1,
            fiber: 2.4,
            sugar: 9,
            vitamins: ["C", "Folate"],
            minerals: ["Calcium", "Potassium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: true
        }
    },
    {
        id: 4,
        name: "Strawberry",
        category: "fruits",
        emoji: "🍓",
        nutrition: {
            calories: 32,
            protein: 0.7,
            carbs: 8,
            fat: 0.3,
            fiber: 2,
            sugar: 4.9,
            vitamins: ["C", "Folate"],
            minerals: ["Potassium", "Manganese"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 5,
        name: "Blueberry",
        category: "fruits",
        emoji: "🫐",
        nutrition: {
            calories: 57,
            protein: 0.7,
            carbs: 14,
            fat: 0.3,
            fiber: 2.4,
            sugar: 10,
            vitamins: ["C", "K"],
            minerals: ["Manganese"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },

    // Vegetables
    {
        id: 6,
        name: "Broccoli",
        category: "vegetables",
        emoji: "🥦",
        nutrition: {
            calories: 34,
            protein: 2.8,
            carbs: 7,
            fat: 0.4,
            fiber: 2.6,
            sugar: 1.5,
            vitamins: ["C", "K", "Folate"],
            minerals: ["Iron", "Potassium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 7,
        name: "Spinach",
        category: "vegetables",
        emoji: "🥬",
        nutrition: {
            calories: 23,
            protein: 2.9,
            carbs: 3.6,
            fat: 0.4,
            fiber: 2.2,
            sugar: 0.4,
            vitamins: ["K", "A", "C", "Folate"],
            minerals: ["Iron", "Calcium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 8,
        name: "Carrot",
        category: "vegetables",
        emoji: "🥕",
        nutrition: {
            calories: 41,
            protein: 0.9,
            carbs: 10,
            fat: 0.2,
            fiber: 2.8,
            sugar: 4.7,
            vitamins: ["A", "K"],
            minerals: ["Potassium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: true
        }
    },
    {
        id: 9,
        name: "Bell Pepper",
        category: "vegetables",
        emoji: "🫑",
        nutrition: {
            calories: 31,
            protein: 1,
            carbs: 7,
            fat: 0.3,
            fiber: 2.5,
            sugar: 4.2,
            vitamins: ["C", "A"],
            minerals: ["Potassium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 10,
        name: "Tomato",
        category: "vegetables",
        emoji: "🍅",
        nutrition: {
            calories: 18,
            protein: 0.9,
            carbs: 3.9,
            fat: 0.2,
            fiber: 1.2,
            sugar: 2.6,
            vitamins: ["C", "K"],
            minerals: ["Potassium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },

    // Proteins
    {
        id: 11,
        name: "Chicken Breast",
        category: "proteins",
        emoji: "🐔",
        nutrition: {
            calories: 165,
            protein: 31,
            carbs: 0,
            fat: 3.6,
            fiber: 0,
            sugar: 0,
            vitamins: ["B6", "Niacin"],
            minerals: ["Phosphorus", "Selenium"]
        },
        dietaryInfo: {
            vegan: false,
            vegetarian: false,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 12,
        name: "Salmon",
        category: "proteins",
        emoji: "🐟",
        nutrition: {
            calories: 208,
            protein: 22,
            carbs: 0,
            fat: 12,
            fiber: 0,
            sugar: 0,
            vitamins: ["D", "B12"],
            minerals: ["Selenium", "Potassium"]
        },
        dietaryInfo: {
            vegan: false,
            vegetarian: false,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 13,
        name: "Eggs",
        category: "proteins",
        emoji: "🥚",
        nutrition: {
            calories: 155,
            protein: 13,
            carbs: 1.1,
            fat: 11,
            fiber: 0,
            sugar: 1.1,
            vitamins: ["B12", "D"],
            minerals: ["Selenium", "Choline"]
        },
        dietaryInfo: {
            vegan: false,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 14,
        name: "Black Beans",
        category: "proteins",
        emoji: "🫘",
        nutrition: {
            calories: 132,
            protein: 8.9,
            carbs: 23,
            fat: 0.5,
            fiber: 8.7,
            sugar: 0.3,
            vitamins: ["Folate", "B1"],
            minerals: ["Iron", "Magnesium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: false
        }
    },
    {
        id: 15,
        name: "Tofu",
        category: "proteins",
        emoji: "🥩",
        nutrition: {
            calories: 76,
            protein: 8,
            carbs: 1.9,
            fat: 4.8,
            fiber: 0.3,
            sugar: 0.6,
            vitamins: ["B1", "Folate"],
            minerals: ["Calcium", "Iron"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: false
        }
    },

    // Grains
    {
        id: 16,
        name: "Brown Rice",
        category: "grains",
        emoji: "🍚",
        nutrition: {
            calories: 112,
            protein: 2.6,
            carbs: 23,
            fat: 0.9,
            fiber: 1.8,
            sugar: 0.4,
            vitamins: ["B1", "B3"],
            minerals: ["Manganese", "Selenium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: false
        }
    },
    {
        id: 17,
        name: "Quinoa",
        category: "grains",
        emoji: "🌾",
        nutrition: {
            calories: 120,
            protein: 4.4,
            carbs: 22,
            fat: 1.9,
            fiber: 2.8,
            sugar: 0.9,
            vitamins: ["Folate", "B6"],
            minerals: ["Manganese", "Phosphorus"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: false
        }
    },
    {
        id: 18,
        name: "Oats",
        category: "grains",
        emoji: "🥣",
        nutrition: {
            calories: 68,
            protein: 2.4,
            carbs: 12,
            fat: 1.4,
            fiber: 1.7,
            sugar: 0.3,
            vitamins: ["B1", "B5"],
            minerals: ["Manganese", "Phosphorus"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: false,
            dairyFree: true,
            keto: false,
            paleo: false
        }
    },
    {
        id: 19,
        name: "Whole Wheat Bread",
        category: "grains",
        emoji: "🍞",
        nutrition: {
            calories: 69,
            protein: 3.6,
            carbs: 12,
            fat: 1.2,
            fiber: 1.9,
            sugar: 1.4,
            vitamins: ["B1", "Folate"],
            minerals: ["Iron", "Magnesium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: false,
            dairyFree: true,
            keto: false,
            paleo: false
        }
    },

    // Dairy
    {
        id: 20,
        name: "Greek Yogurt",
        category: "dairy",
        emoji: "🥛",
        nutrition: {
            calories: 59,
            protein: 10,
            carbs: 3.6,
            fat: 0.4,
            fiber: 0,
            sugar: 3.6,
            vitamins: ["B12", "B2"],
            minerals: ["Calcium", "Phosphorus"]
        },
        dietaryInfo: {
            vegan: false,
            vegetarian: true,
            glutenFree: true,
            dairyFree: false,
            keto: true,
            paleo: false
        }
    },
    {
        id: 21,
        name: "Cheddar Cheese",
        category: "dairy",
        emoji: "🧀",
        nutrition: {
            calories: 113,
            protein: 7,
            carbs: 1,
            fat: 9,
            fiber: 0,
            sugar: 0.5,
            vitamins: ["A", "B12"],
            minerals: ["Calcium", "Phosphorus"]
        },
        dietaryInfo: {
            vegan: false,
            vegetarian: true,
            glutenFree: true,
            dairyFree: false,
            keto: true,
            paleo: false
        }
    },
    {
        id: 22,
        name: "Milk",
        category: "dairy",
        emoji: "🥛",
        nutrition: {
            calories: 42,
            protein: 3.4,
            carbs: 5,
            fat: 1,
            fiber: 0,
            sugar: 5,
            vitamins: ["D", "B12"],
            minerals: ["Calcium", "Phosphorus"]
        },
        dietaryInfo: {
            vegan: false,
            vegetarian: true,
            glutenFree: true,
            dairyFree: false,
            keto: false,
            paleo: false
        }
    },
    {
        id: 23,
        name: "Almonds",
        category: "proteins",
        emoji: "🥜",
        nutrition: {
            calories: 161,
            protein: 6,
            carbs: 6,
            fat: 14,
            fiber: 3.5,
            sugar: 1.2,
            vitamins: ["E", "B2"],
            minerals: ["Magnesium", "Calcium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 24,
        name: "Avocado",
        category: "fruits",
        emoji: "🥑",
        nutrition: {
            calories: 160,
            protein: 2,
            carbs: 9,
            fat: 15,
            fiber: 7,
            sugar: 0.7,
            vitamins: ["K", "Folate"],
            minerals: ["Potassium", "Magnesium"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: true,
            paleo: true
        }
    },
    {
        id: 25,
        name: "Sweet Potato",
        category: "vegetables",
        emoji: "🍠",
        nutrition: {
            calories: 86,
            protein: 1.6,
            carbs: 20,
            fat: 0.1,
            fiber: 3,
            sugar: 4.2,
            vitamins: ["A", "C"],
            minerals: ["Potassium", "Manganese"]
        },
        dietaryInfo: {
            vegan: true,
            vegetarian: true,
            glutenFree: true,
            dairyFree: true,
            keto: false,
            paleo: true
        }
    }
];

// Sample Recipes
const SAMPLE_RECIPES = [
    {
        id: 1,
        name: "Mediterranean Quinoa Bowl",
        ingredients: [
            "1 cup quinoa",
            "2 cups vegetable broth",
            "1 cucumber, diced",
            "2 tomatoes, diced",
            "1/2 red onion, sliced",
            "1/4 cup olives",
            "1/4 cup feta cheese",
            "2 tbsp olive oil",
            "1 lemon, juiced",
            "Fresh herbs (parsley, mint)"
        ],
        instructions: "Cook quinoa in vegetable broth until fluffy. Let cool. Mix with diced vegetables, olives, and feta. Whisk olive oil and lemon juice for dressing. Toss everything together and garnish with fresh herbs.",
        servings: 4,
        rating: 0,
        author: "FoodHub",
        dateAdded: new Date().toISOString()
    },
    {
        id: 2,
        name: "Protein-Packed Smoothie Bowl",
        ingredients: [
            "1 frozen banana",
            "1/2 cup frozen berries",
            "1 scoop protein powder",
            "1/2 cup Greek yogurt",
            "1/4 cup almond milk",
            "1 tbsp almond butter",
            "Toppings: granola, fresh fruit, nuts"
        ],
        instructions: "Blend frozen fruits, protein powder, yogurt, and almond milk until smooth. Pour into bowl and add your favorite toppings like granola, fresh fruit, and nuts.",
        servings: 1,
        rating: 0,
        author: "FoodHub",
        dateAdded: new Date().toISOString()
    },
    {
        id: 3,
        name: "Grilled Chicken & Veggie Plate",
        ingredients: [
            "4 chicken breasts",
            "2 bell peppers, sliced",
            "1 zucchini, sliced",
            "1 red onion, sliced",
            "2 tbsp olive oil",
            "2 cloves garlic, minced",
            "1 tsp herbs (thyme, rosemary)",
            "Salt and pepper to taste"
        ],
        instructions: "Marinate chicken in olive oil, garlic, herbs, salt and pepper for 30 minutes. Grill chicken and vegetables until cooked through. Serve with a side salad or quinoa.",
        servings: 4,
        rating: 0,
        author: "FoodHub",
        dateAdded: new Date().toISOString()
    }
];

// Nutrition Goals (default values)
const DEFAULT_NUTRITION_GOALS = {
    calories: 2000,
    protein: 150,
    carbs: 250,
    fat: 65
};

// Export data for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        FOOD_DATABASE,
        SAMPLE_RECIPES,
        DEFAULT_NUTRITION_GOALS
    };
}