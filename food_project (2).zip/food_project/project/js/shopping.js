// Shopping List Manager
class ShoppingManager {
    constructor() {
        this.shoppingList = [];
    }

    init() {
        this.loadShoppingList();
        this.bindEvents();
        this.renderShoppingList();
    }

    loadShoppingList() {
        this.shoppingList = storage.getShoppingList();
    }

    bindEvents() {
        // Generate list button
        const generateBtn = document.getElementById('generate-list');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => {
                this.generateFromMealPlan();
            });
        }

        // Clear list button
        const clearBtn = document.getElementById('clear-list');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.clearShoppingList();
            });
        }

        // Email list button
        const emailBtn = document.getElementById('email-list');
        if (emailBtn) {
            emailBtn.addEventListener('click', () => {
                this.emailShoppingList();
            });
        }
    }

    generateFromMealPlan() {
        if (!window.mealPlanner) {
            navigation.showNotification('Meal planner not available', 'error');
            return;
        }

        const allFoods = mealPlanner.getAllMealFoods();
        
        if (allFoods.length === 0) {
            navigation.showNotification('No foods in your meal plan to generate shopping list', 'warning');
            return;
        }

        // Group foods by name to avoid duplicates
        const foodMap = new Map();
        
        allFoods.forEach(food => {
            if (foodMap.has(food.name)) {
                foodMap.get(food.name).quantity += 1;
            } else {
                foodMap.set(food.name, {
                    id: food.id,
                    name: food.name,
                    category: food.category,
                    emoji: food.emoji,
                    quantity: 1,
                    completed: false,
                    addedAt: new Date().toISOString(),
                    fromMealPlan: true
                });
            }
        });

        // Add new items to shopping list (avoid duplicates)
        let addedCount = 0;
        foodMap.forEach(item => {
            const existingItem = this.shoppingList.find(existing => existing.name === item.name);
            if (!existingItem) {
                this.shoppingList.push(item);
                addedCount++;
            }
        });

        // Save and update UI
        storage.saveShoppingList(this.shoppingList);
        this.renderShoppingList();

        navigation.showNotification(`Added ${addedCount} items to shopping list`, 'success');
    }

    addItem(name, category = 'other') {
        const newItem = {
            id: Date.now(),
            name: name.trim(),
            category: category,
            quantity: 1,
            completed: false,
            addedAt: new Date().toISOString(),
            fromMealPlan: false
        };

        this.shoppingList.push(newItem);
        storage.saveShoppingList(this.shoppingList);
        this.renderShoppingList();

        navigation.showNotification(`${name} added to shopping list`, 'success');
    }

    removeItem(index) {
        if (index >= 0 && index < this.shoppingList.length) {
            const item = this.shoppingList[index];
            this.shoppingList.splice(index, 1);
            storage.saveShoppingList(this.shoppingList);
            this.renderShoppingList();

            navigation.showNotification(`${item.name} removed from shopping list`, 'success');
        }
    }

    toggleItem(index) {
        if (index >= 0 && index < this.shoppingList.length) {
            this.shoppingList[index].completed = !this.shoppingList[index].completed;
            storage.saveShoppingList(this.shoppingList);
            this.renderShoppingList();
        }
    }

    clearShoppingList() {
        if (!confirm('Are you sure you want to clear your entire shopping list?')) {
            return;
        }

        this.shoppingList = [];
        storage.saveShoppingList(this.shoppingList);
        this.renderShoppingList();

        navigation.showNotification('Shopping list cleared', 'success');
    }

    clearCompletedItems() {
        const completedCount = this.shoppingList.filter(item => item.completed).length;
        
        if (completedCount === 0) {
            navigation.showNotification('No completed items to clear', 'info');
            return;
        }

        if (!confirm(`Remove ${completedCount} completed items from your shopping list?`)) {
            return;
        }

        this.shoppingList = this.shoppingList.filter(item => !item.completed);
        storage.saveShoppingList(this.shoppingList);
        this.renderShoppingList();

        navigation.showNotification(`${completedCount} completed items removed`, 'success');
    }

    renderShoppingList() {
        const container = document.getElementById('shopping-list');
        if (!container) return;

        if (this.shoppingList.length === 0) {
            container.innerHTML = `
                <div class="empty-shopping-list">
                    <h3>Your shopping list is empty</h3>
                    <p>Generate a list from your meal plan or add items manually</p>
                    <button class="btn btn-primary" onclick="shoppingManager.showAddItemModal()">Add Item</button>
                </div>
            `;
            return;
        }

        // Group items by category
        const groupedItems = this.groupItemsByCategory();

        let html = `
            <div class="shopping-list-header">
                <h3>Shopping List (${this.shoppingList.length} items)</h3>
                <div class="shopping-list-actions">
                    <button class="btn btn-outline btn-sm" onclick="shoppingManager.showAddItemModal()">Add Item</button>
                    <button class="btn btn-outline btn-sm" onclick="shoppingManager.clearCompletedItems()">Clear Completed</button>
                </div>
            </div>
        `;

        Object.entries(groupedItems).forEach(([category, items]) => {
            html += `
                <div class="shopping-category">
                    <h4 class="shopping-category-title">${this.formatCategoryName(category)}</h4>
                    <div class="shopping-category-items">
                        ${items.map((item, index) => this.createShoppingItem(item, this.shoppingList.indexOf(item))).join('')}
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;

        // Add event listeners
        this.bindShoppingItemEvents();
    }

    groupItemsByCategory() {
        const grouped = {};
        
        this.shoppingList.forEach(item => {
            const category = item.category || 'other';
            if (!grouped[category]) {
                grouped[category] = [];
            }
            grouped[category].push(item);
        });

        return grouped;
    }

    formatCategoryName(category) {
        const categoryNames = {
            fruits: '🍎 Fruits',
            vegetables: '🥕 Vegetables',
            proteins: '🥩 Proteins',
            grains: '🌾 Grains',
            dairy: '🥛 Dairy',
            other: '📦 Other'
        };
        return categoryNames[category] || `📦 ${category}`;
    }

    createShoppingItem(item, index) {
        return `
            <div class="shopping-item ${item.completed ? 'completed' : ''}" data-index="${index}">
                <input type="checkbox" ${item.completed ? 'checked' : ''} onchange="shoppingManager.toggleItem(${index})">
                <div class="shopping-item-info">
                    <span class="shopping-item-name">${item.emoji || ''} ${item.name}</span>
                    ${item.quantity > 1 ? `<span class="shopping-item-quantity">x${item.quantity}</span>` : ''}
                </div>
                <button class="shopping-item-remove" onclick="shoppingManager.removeItem(${index})">✕</button>
            </div>
        `;
    }

    bindShoppingItemEvents() {
        // Event listeners are bound inline in the HTML for simplicity
        // In a larger app, you might want to use event delegation
    }

    showAddItemModal() {
        const modalContent = `
            <div class="add-item-form">
                <h3>Add Item to Shopping List</h3>
                <form id="add-item-form">
                    <div class="form-group">
                        <label for="item-name">Item Name</label>
                        <input type="text" id="item-name" required placeholder="Enter item name">
                    </div>
                    <div class="form-group">
                        <label for="item-category">Category</label>
                        <select id="item-category">
                            <option value="other">Other</option>
                            <option value="fruits">Fruits</option>
                            <option value="vegetables">Vegetables</option>
                            <option value="proteins">Proteins</option>
                            <option value="grains">Grains</option>
                            <option value="dairy">Dairy</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Add Item</button>
                        <button type="button" class="btn btn-outline" onclick="shoppingManager.hideAddItemModal()">Cancel</button>
                    </div>
                </form>
            </div>
        `;

        // Show custom modal
        if (window.foodExplorer) {
            foodExplorer.showCustomModal('Add Shopping Item', modalContent);
        }

        // Bind form submission
        const form = document.getElementById('add-item-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const name = document.getElementById('item-name').value;
                const category = document.getElementById('item-category').value;
                
                if (name.trim()) {
                    this.addItem(name, category);
                    this.hideAddItemModal();
                }
            });
        }
    }

    hideAddItemModal() {
        if (window.foodExplorer) {
            foodExplorer.hideCustomModal();
        }
    }

    emailShoppingList() {
        if (this.shoppingList.length === 0) {
            navigation.showNotification('Shopping list is empty', 'warning');
            return;
        }

        const subject = encodeURIComponent('My Shopping List from FoodHub');
        const body = this.generateEmailBody();
        const mailtoLink = `mailto:?subject=${subject}&body=${encodeURIComponent(body)}`;

        window.open(mailtoLink);
        navigation.showNotification('Opening email client...', 'info');
    }

    generateEmailBody() {
        let body = 'My Shopping List from FoodHub\n';
        body += '================================\n\n';

        const groupedItems = this.groupItemsByCategory();

        Object.entries(groupedItems).forEach(([category, items]) => {
            body += `${this.formatCategoryName(category)}\n`;
            body += '-'.repeat(this.formatCategoryName(category).length) + '\n';
            
            items.forEach(item => {
                const status = item.completed ? '✓' : '☐';
                const quantity = item.quantity > 1 ? ` (x${item.quantity})` : '';
                body += `${status} ${item.name}${quantity}\n`;
            });
            
            body += '\n';
        });

        body += `\nGenerated on ${new Date().toLocaleDateString()}\n`;
        body += 'Created with FoodHub - Your Complete Food Companion';

        return body;
    }

    printShoppingList() {
        if (this.shoppingList.length === 0) {
            navigation.showNotification('Shopping list is empty', 'warning');
            return;
        }

        const printWindow = window.open('', '_blank');
        const printContent = this.generatePrintContent();
        
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.print();
    }

    generatePrintContent() {
        const groupedItems = this.groupItemsByCategory();
        
        let html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Shopping List - FoodHub</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    h1 { color: #0ea5e9; border-bottom: 2px solid #0ea5e9; padding-bottom: 10px; }
                    h2 { color: #475569; margin-top: 30px; }
                    .item { margin: 5px 0; padding: 5px; border-bottom: 1px dotted #ccc; }
                    .completed { text-decoration: line-through; opacity: 0.6; }
                    .footer { margin-top: 40px; font-size: 12px; color: #666; }
                </style>
            </head>
            <body>
                <h1>🛒 Shopping List</h1>
                <p>Generated on ${new Date().toLocaleDateString()}</p>
        `;

        Object.entries(groupedItems).forEach(([category, items]) => {
            html += `<h2>${this.formatCategoryName(category)}</h2>`;
            
            items.forEach(item => {
                const completedClass = item.completed ? 'completed' : '';
                const checkbox = item.completed ? '☑' : '☐';
                const quantity = item.quantity > 1 ? ` (x${item.quantity})` : '';
                
                html += `<div class="item ${completedClass}">${checkbox} ${item.name}${quantity}</div>`;
            });
        });

        html += `
                <div class="footer">
                    <p>Created with FoodHub - Your Complete Food Companion</p>
                </div>
            </body>
            </html>
        `;

        return html;
    }

    // Export shopping list as JSON
    exportShoppingList() {
        const data = {
            shoppingList: this.shoppingList,
            exportDate: new Date().toISOString(),
            totalItems: this.shoppingList.length,
            completedItems: this.shoppingList.filter(item => item.completed).length
        };

        const dataStr = JSON.stringify(data, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `shopping-list-${new Date().toISOString().split('T')[0]}.json`;
        link.click();

        URL.revokeObjectURL(url);
        navigation.showNotification('Shopping list exported!', 'success');
    }
}

// Create global shopping manager instance
const shoppingManager = new ShoppingManager();