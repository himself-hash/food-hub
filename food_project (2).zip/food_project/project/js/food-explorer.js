// Food Explorer Module
class FoodExplorer {
    constructor() {
        this.foods = FOOD_DATABASE;
        this.filteredFoods = [...this.foods];
        this.currentFilters = {
            search: '',
            category: '',
            sort: ''
        };
        this.userPreferences = [];
    }

    init() {
        this.loadUserPreferences();
        this.bindEvents();
        this.renderFoods();
    }

    loadUserPreferences() {
        this.userPreferences = storage.getPreferences();
    }

    bindEvents() {
        // Search input
        const searchInput = document.getElementById('food-search');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.currentFilters.search = e.target.value.toLowerCase();
                this.applyFilters();
            });
        }

        // Category filter
        const categoryFilter = document.getElementById('category-filter');
        if (categoryFilter) {
            categoryFilter.addEventListener('change', (e) => {
                this.currentFilters.category = e.target.value;
                this.applyFilters();
            });
        }

        // Sort filter
        const sortFilter = document.getElementById('sort-filter');
        if (sortFilter) {
            sortFilter.addEventListener('change', (e) => {
                this.currentFilters.sort = e.target.value;
                this.applyFilters();
            });
        }
    }

    applyFilters() {
        let filtered = [...this.foods];

        // Apply search filter
        if (this.currentFilters.search) {
            filtered = filtered.filter(food => 
                food.name.toLowerCase().includes(this.currentFilters.search) ||
                food.category.toLowerCase().includes(this.currentFilters.search)
            );
        }

        // Apply category filter
        if (this.currentFilters.category) {
            filtered = filtered.filter(food => food.category === this.currentFilters.category);
        }

        // Apply dietary preferences filter
        if (this.userPreferences.length > 0) {
            filtered = filtered.filter(food => {
                return this.userPreferences.every(pref => food.dietaryInfo[pref] === true);
            });
        }

        // Apply sorting
        if (this.currentFilters.sort) {
            filtered.sort((a, b) => {
                const aValue = a.nutrition[this.currentFilters.sort];
                const bValue = b.nutrition[this.currentFilters.sort];
                return bValue - aValue; // Descending order
            });
        }

        this.filteredFoods = filtered;
        this.renderFoods();
    }

    renderFoods() {
        const foodGrid = document.getElementById('food-grid');
        if (!foodGrid) return;

        if (this.filteredFoods.length === 0) {
            foodGrid.innerHTML = `
                <div class="no-results">
                    <h3>No foods found</h3>
                    <p>Try adjusting your search or filters</p>
                </div>
            `;
            return;
        }

        foodGrid.innerHTML = this.filteredFoods.map(food => this.createFoodCard(food)).join('');

        // Add click events to food cards
        const foodCards = foodGrid.querySelectorAll('.food-card');
        foodCards.forEach(card => {
            card.addEventListener('click', () => {
                const foodId = parseInt(card.dataset.foodId);
                this.showFoodDetails(foodId);
            });
        });
    }

    createFoodCard(food) {
        const isCompatible = this.userPreferences.length === 0 || 
            this.userPreferences.every(pref => food.dietaryInfo[pref] === true);

        return `
            <div class="food-card ${!isCompatible ? 'incompatible' : ''}" data-food-id="${food.id}">
                <div class="food-card-image">
                    ${food.emoji}
                </div>
                <div class="food-card-content">
                    <h3 class="food-card-title">${food.name}</h3>
                    <span class="food-card-category">${food.category}</span>
                    
                    <div class="food-card-nutrition">
                        <div class="nutrition-item">
                            <span>Calories</span>
                            <span>${food.nutrition.calories}</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Protein</span>
                            <span>${food.nutrition.protein}g</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Carbs</span>
                            <span>${food.nutrition.carbs}g</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Fat</span>
                            <span>${food.nutrition.fat}g</span>
                        </div>
                    </div>
                    
                    ${!isCompatible ? '<div class="dietary-warning">⚠️ May not match your dietary preferences</div>' : ''}
                </div>
            </div>
        `;
    }

    showFoodDetails(foodId) {
        const food = this.foods.find(f => f.id === foodId);
        if (!food) return;

        // Create detailed modal content
        const modalContent = `
            <div class="food-details">
                <div class="food-details-header">
                    <div class="food-emoji">${food.emoji}</div>
                    <div>
                        <h2>${food.name}</h2>
                        <span class="food-category">${food.category}</span>
                    </div>
                </div>
                
                <div class="food-details-nutrition">
                    <h3>Nutrition Facts (per 100g)</h3>
                    <div class="nutrition-grid">
                        <div class="nutrition-item">
                            <span>Calories</span>
                            <span>${food.nutrition.calories}</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Protein</span>
                            <span>${food.nutrition.protein}g</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Carbohydrates</span>
                            <span>${food.nutrition.carbs}g</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Fat</span>
                            <span>${food.nutrition.fat}g</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Fiber</span>
                            <span>${food.nutrition.fiber}g</span>
                        </div>
                        <div class="nutrition-item">
                            <span>Sugar</span>
                            <span>${food.nutrition.sugar}g</span>
                        </div>
                    </div>
                </div>
                
                <div class="food-details-vitamins">
                    <h3>Vitamins & Minerals</h3>
                    <div class="vitamins-list">
                        ${food.nutrition.vitamins.map(vitamin => `<span class="vitamin-tag">Vitamin ${vitamin}</span>`).join('')}
                        ${food.nutrition.minerals.map(mineral => `<span class="mineral-tag">${mineral}</span>`).join('')}
                    </div>
                </div>
                
                <div class="food-details-dietary">
                    <h3>Dietary Information</h3>
                    <div class="dietary-tags">
                        ${Object.entries(food.dietaryInfo).map(([key, value]) => 
                            value ? `<span class="dietary-tag dietary-tag-yes">${this.formatDietaryLabel(key)}</span>` : 
                                   `<span class="dietary-tag dietary-tag-no">Not ${this.formatDietaryLabel(key)}</span>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="food-details-actions">
                    <button class="btn btn-primary" onclick="foodExplorer.addToMeal(${food.id})">Add to Meal</button>
                    <button class="btn btn-outline" onclick="foodExplorer.addToShopping(${food.id})">Add to Shopping List</button>
                </div>
            </div>
        `;

        // Show in modal
        this.showCustomModal('Food Details', modalContent);
    }

    formatDietaryLabel(key) {
        const labels = {
            vegan: 'Vegan',
            vegetarian: 'Vegetarian',
            glutenFree: 'Gluten-Free',
            dairyFree: 'Dairy-Free',
            keto: 'Keto-Friendly',
            paleo: 'Paleo-Friendly'
        };
        return labels[key] || key;
    }

    addToMeal(foodId) {
        const food = this.foods.find(f => f.id === foodId);
        if (!food) return;

        // Show meal selection modal
        const mealOptions = `
            <div class="meal-selection">
                <h3>Add ${food.name} to which meal?</h3>
                <div class="meal-buttons">
                    <button class="btn btn-outline" onclick="foodExplorer.addFoodToMeal(${foodId}, 'breakfast')">Breakfast</button>
                    <button class="btn btn-outline" onclick="foodExplorer.addFoodToMeal(${foodId}, 'lunch')">Lunch</button>
                    <button class="btn btn-outline" onclick="foodExplorer.addFoodToMeal(${foodId}, 'dinner')">Dinner</button>
                    <button class="btn btn-outline" onclick="foodExplorer.addFoodToMeal(${foodId}, 'snacks')">Snacks</button>
                </div>
            </div>
        `;

        this.showCustomModal('Select Meal', mealOptions);
    }

    addFoodToMeal(foodId, mealType) {
        const food = this.foods.find(f => f.id === foodId);
        if (!food) return;

        // Get current meals
        const meals = storage.getMeals();
        
        // Add food to specified meal
        if (!meals[mealType]) {
            meals[mealType] = [];
        }
        
        meals[mealType].push({
            ...food,
            addedAt: new Date().toISOString(),
            quantity: 1
        });

        // Save meals
        storage.saveMeals(meals);

        // Close modal and show success
        this.hideCustomModal();
        navigation.showNotification(`${food.name} added to ${mealType}!`, 'success');
    }

    addToShopping(foodId) {
        const food = this.foods.find(f => f.id === foodId);
        if (!food) return;

        // Get current shopping list
        const shoppingList = storage.getShoppingList();
        
        // Check if item already exists
        const existingItem = shoppingList.find(item => item.id === foodId);
        if (existingItem) {
            navigation.showNotification(`${food.name} is already in your shopping list`, 'warning');
            return;
        }

        // Add to shopping list
        shoppingList.push({
            id: food.id,
            name: food.name,
            category: food.category,
            completed: false,
            addedAt: new Date().toISOString()
        });

        // Save shopping list
        storage.saveShoppingList(shoppingList);

        navigation.showNotification(`${food.name} added to shopping list!`, 'success');
    }

    showCustomModal(title, content) {
        // Create modal if it doesn't exist
        let modal = document.getElementById('custom-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'custom-modal';
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="custom-modal-title"></h3>
                        <button class="modal-close" onclick="foodExplorer.hideCustomModal()">&times;</button>
                    </div>
                    <div class="modal-body" id="custom-modal-body"></div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Set content
        document.getElementById('custom-modal-title').textContent = title;
        document.getElementById('custom-modal-body').innerHTML = content;

        // Show modal
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    hideCustomModal() {
        const modal = document.getElementById('custom-modal');
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    // Get food by ID (utility method)
    getFoodById(id) {
        return this.foods.find(food => food.id === id);
    }

    // Get foods by category (utility method)
    getFoodsByCategory(category) {
        return this.foods.filter(food => food.category === category);
    }
}

// Create global food explorer instance
const foodExplorer = new FoodExplorer();