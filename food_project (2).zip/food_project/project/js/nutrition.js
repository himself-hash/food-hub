// Nutrition Tracker Module
class NutritionTracker {
    constructor() {
        this.goals = DEFAULT_NUTRITION_GOALS;
        this.currentTotals = {
            calories: 0,
            protein: 0,
            carbs: 0,
            fat: 0
        };
    }

    init() {
        this.loadGoals();
        this.updateFromMeals();
        this.renderCharts();
    }

    loadGoals() {
        this.goals = storage.getGoals();
    }

    updateFromMeals() {
        if (window.mealPlanner) {
            this.currentTotals = mealPlanner.calculateDailyTotals();
        }
    }

    updateCharts(totals = null) {
        if (totals) {
            this.currentTotals = totals;
        }
        this.renderCharts();
    }

    renderCharts() {
        this.renderPieChart();
        this.renderProgressBars();
    }

    renderPieChart() {
        const { protein, carbs, fat } = this.currentTotals;
        
        // Calculate calories from macros
        const proteinCals = protein * 4;
        const carbsCals = carbs * 4;
        const fatCals = fat * 9;
        const totalMacroCals = proteinCals + carbsCals + fatCals;

        if (totalMacroCals === 0) {
            // Show empty chart
            this.updatePieChartDisplay(0, 0, 0);
            return;
        }

        // Calculate percentages
        const proteinPercent = (proteinCals / totalMacroCals) * 100;
        const carbsPercent = (carbsCals / totalMacroCals) * 100;
        const fatPercent = (fatCals / totalMacroCals) * 100;

        this.updatePieChartDisplay(proteinPercent, carbsPercent, fatPercent);
    }

    updatePieChartDisplay(proteinPercent, carbsPercent, fatPercent) {
        const pieChart = document.getElementById('macro-chart');
        if (!pieChart) return;

        // Calculate angles for conic gradient
        const proteinAngle = (proteinPercent / 100) * 360;
        const carbsAngle = proteinAngle + (carbsPercent / 100) * 360;

        // Update pie chart background
        pieChart.style.background = `conic-gradient(
            var(--primary-500) 0deg ${proteinAngle}deg,
            var(--success-500) ${proteinAngle}deg ${carbsAngle}deg,
            var(--warning-500) ${carbsAngle}deg 360deg
        )`;

        // Add center circle for donut effect
        if (!pieChart.querySelector('.pie-center')) {
            const center = document.createElement('div');
            center.className = 'pie-center';
            center.style.cssText = `
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 60%;
                height: 60%;
                background: white;
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                font-size: var(--font-size-sm);
                font-weight: 600;
                color: var(--neutral-700);
            `;
            center.innerHTML = `
                <div>Total</div>
                <div style="font-size: var(--font-size-lg); color: var(--neutral-800);">
                    ${Math.round(this.currentTotals.calories)} cal
                </div>
            `;
            pieChart.appendChild(center);
        } else {
            const center = pieChart.querySelector('.pie-center');
            center.innerHTML = `
                <div>Total</div>
                <div style="font-size: var(--font-size-lg); color: var(--neutral-800);">
                    ${Math.round(this.currentTotals.calories)} cal
                </div>
            `;
        }
    }

    renderProgressBars() {
        this.updateProgressBar('calories', this.currentTotals.calories, this.goals.calories);
        this.updateProgressBar('protein', this.currentTotals.protein, this.goals.protein);
        this.updateProgressBar('carbs', this.currentTotals.carbs, this.goals.carbs);
        this.updateProgressBar('fat', this.currentTotals.fat, this.goals.fat);
    }

    updateProgressBar(nutrient, current, goal) {
        const progressFill = document.getElementById(`${nutrient}-progress`);
        const progressText = document.getElementById(`${nutrient}-text`);

        if (!progressFill || !progressText) return;

        const percentage = Math.min((current / goal) * 100, 100);
        
        // Update progress bar
        progressFill.style.width = `${percentage}%`;
        
        // Update color based on progress
        if (percentage >= 100) {
            progressFill.style.background = 'linear-gradient(90deg, var(--success-500), var(--success-600))';
        } else if (percentage >= 80) {
            progressFill.style.background = 'linear-gradient(90deg, var(--warning-500), var(--warning-600))';
        } else {
            progressFill.style.background = 'linear-gradient(90deg, var(--primary-500), var(--primary-600))';
        }

        // Update text
        const unit = nutrient === 'calories' ? '' : 'g';
        progressText.textContent = `${Math.round(current)}${unit} / ${goal}${unit}`;
    }

    generateNutritionReport() {
        const report = {
            date: new Date().toISOString().split('T')[0],
            goals: this.goals,
            actual: this.currentTotals,
            percentages: {
                calories: (this.currentTotals.calories / this.goals.calories) * 100,
                protein: (this.currentTotals.protein / this.goals.protein) * 100,
                carbs: (this.currentTotals.carbs / this.goals.carbs) * 100,
                fat: (this.currentTotals.fat / this.goals.fat) * 100
            },
            recommendations: this.generateRecommendations()
        };

        return report;
    }

    generateRecommendations() {
        const recommendations = [];
        const { calories, protein, carbs, fat } = this.currentTotals;
        const goals = this.goals;

        // Calorie recommendations
        if (calories < goals.calories * 0.8) {
            recommendations.push({
                type: 'calories',
                message: 'You\'re under your calorie goal. Consider adding a healthy snack.',
                priority: 'medium'
            });
        } else if (calories > goals.calories * 1.2) {
            recommendations.push({
                type: 'calories',
                message: 'You\'ve exceeded your calorie goal. Consider lighter options for remaining meals.',
                priority: 'high'
            });
        }

        // Protein recommendations
        if (protein < goals.protein * 0.7) {
            recommendations.push({
                type: 'protein',
                message: 'Your protein intake is low. Add lean meats, eggs, or legumes.',
                priority: 'high'
            });
        }

        // Carb recommendations
        if (carbs < goals.carbs * 0.5) {
            recommendations.push({
                type: 'carbs',
                message: 'Consider adding complex carbohydrates like whole grains or fruits.',
                priority: 'medium'
            });
        }

        // Fat recommendations
        if (fat < goals.fat * 0.5) {
            recommendations.push({
                type: 'fat',
                message: 'Include healthy fats like avocados, nuts, or olive oil.',
                priority: 'medium'
            });
        }

        return recommendations;
    }

    showNutritionTips() {
        const tips = [
            "Aim for a balanced plate: 1/2 vegetables, 1/4 protein, 1/4 whole grains",
            "Stay hydrated - drink at least 8 glasses of water daily",
            "Include a variety of colorful fruits and vegetables",
            "Choose whole grains over refined grains",
            "Limit processed foods and added sugars",
            "Eat mindfully and listen to your hunger cues",
            "Include healthy fats like nuts, seeds, and olive oil",
            "Plan your meals ahead to make healthier choices"
        ];

        const randomTip = tips[Math.floor(Math.random() * tips.length)];
        
        navigation.showNotification(`💡 Nutrition Tip: ${randomTip}`, 'info');
    }

    exportNutritionData() {
        const report = this.generateNutritionReport();
        const dataStr = JSON.stringify(report, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `nutrition-report-${report.date}.json`;
        link.click();

        URL.revokeObjectURL(url);
        navigation.showNotification('Nutrition report exported!', 'success');
    }

    // Calculate BMI (if height and weight are available)
    calculateBMI(weight, height) {
        // weight in kg, height in cm
        const heightInMeters = height / 100;
        return weight / (heightInMeters * heightInMeters);
    }

    // Calculate daily calorie needs (basic formula)
    calculateDailyCalorieNeeds(weight, height, age, gender, activityLevel) {
        let bmr;
        
        // Mifflin-St Jeor Equation
        if (gender === 'male') {
            bmr = 10 * weight + 6.25 * height - 5 * age + 5;
        } else {
            bmr = 10 * weight + 6.25 * height - 5 * age - 161;
        }

        // Activity multipliers
        const activityMultipliers = {
            sedentary: 1.2,
            light: 1.375,
            moderate: 1.55,
            active: 1.725,
            veryActive: 1.9
        };

        return Math.round(bmr * (activityMultipliers[activityLevel] || 1.2));
    }
}

// Create global nutrition tracker instance
const nutritionTracker = new NutritionTracker();