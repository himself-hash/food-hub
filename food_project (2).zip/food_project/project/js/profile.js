// Profile Manager
class ProfileManager {
    constructor() {
        this.preferences = [];
        this.goals = DEFAULT_NUTRITION_GOALS;
    }

    init() {
        this.loadUserData();
        this.bindEvents();
        this.updateUI();
    }

    loadUserData() {
        this.preferences = storage.getPreferences();
        this.goals = storage.getGoals();
    }

    bindEvents() {
        // Save preferences button
        const savePreferencesBtn = document.getElementById('save-preferences');
        if (savePreferencesBtn) {
            savePreferencesBtn.addEventListener('click', () => {
                this.savePreferences();
            });
        }

        // Save goals button
        const saveGoalsBtn = document.getElementById('save-goals');
        if (saveGoalsBtn) {
            saveGoalsBtn.addEventListener('click', () => {
                this.saveGoals();
            });
        }

        // Preference checkboxes
        const preferenceCheckboxes = document.querySelectorAll('.preference-item input[type="checkbox"]');
        preferenceCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updatePreferenceUI(checkbox);
            });
        });
    }

    updateUI() {
        this.updatePreferencesUI();
        this.updateGoalsUI();
    }

    updatePreferencesUI() {
        // Update preference checkboxes
        this.preferences.forEach(pref => {
            const checkbox = document.getElementById(pref);
            if (checkbox) {
                checkbox.checked = true;
                this.updatePreferenceUI(checkbox);
            }
        });
    }

    updatePreferenceUI(checkbox) {
        const preferenceItem = checkbox.closest('.preference-item');
        if (checkbox.checked) {
            preferenceItem.style.borderColor = 'var(--primary-500)';
            preferenceItem.style.backgroundColor = 'var(--primary-50)';
        } else {
            preferenceItem.style.borderColor = 'var(--neutral-200)';
            preferenceItem.style.backgroundColor = 'transparent';
        }
    }

    updateGoalsUI() {
        // Update goal inputs
        document.getElementById('calorie-goal').value = this.goals.calories;
        document.getElementById('protein-goal').value = this.goals.protein;
        document.getElementById('carbs-goal').value = this.goals.carbs;
        document.getElementById('fat-goal').value = this.goals.fat;
    }

    savePreferences() {
        const checkboxes = document.querySelectorAll('.preference-item input[type="checkbox"]');
        const selectedPreferences = [];

        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selectedPreferences.push(checkbox.value);
            }
        });

        this.preferences = selectedPreferences;
        storage.savePreferences(this.preferences);

        // Update food explorer if it exists
        if (window.foodExplorer) {
            foodExplorer.loadUserPreferences();
            foodExplorer.applyFilters();
        }

        navigation.showNotification('Dietary preferences saved!', 'success');
    }

    saveGoals() {
        const calories = parseInt(document.getElementById('calorie-goal').value);
        const protein = parseInt(document.getElementById('protein-goal').value);
        const carbs = parseInt(document.getElementById('carbs-goal').value);
        const fat = parseInt(document.getElementById('fat-goal').value);

        // Validation
        if (calories < 1000 || calories > 5000) {
            navigation.showNotification('Calorie goal must be between 1000 and 5000', 'error');
            return;
        }

        if (protein < 50 || protein > 300) {
            navigation.showNotification('Protein goal must be between 50g and 300g', 'error');
            return;
        }

        if (carbs < 50 || carbs > 500) {
            navigation.showNotification('Carbs goal must be between 50g and 500g', 'error');
            return;
        }

        if (fat < 20 || fat > 150) {
            navigation.showNotification('Fat goal must be between 20g and 150g', 'error');
            return;
        }

        this.goals = { calories, protein, carbs, fat };
        storage.saveGoals(this.goals);

        // Update nutrition tracker if it exists
        if (window.nutritionTracker) {
            nutritionTracker.loadGoals();
            nutritionTracker.renderCharts();
        }

        navigation.showNotification('Nutrition goals saved!', 'success');
    }

    showProfileStats() {
        const user = auth.getCurrentUser();
        if (!user) {
            navigation.showNotification('Please log in to view profile stats', 'warning');
            return;
        }

        const stats = this.calculateProfileStats();
        
        const modalContent = `
            <div class="profile-stats">
                <h3>Profile Statistics</h3>
                
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-value">${stats.totalMeals}</div>
                        <div class="stat-label">Meals Planned</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${stats.totalRecipes}</div>
                        <div class="stat-label">Recipes Added</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${stats.shoppingItems}</div>
                        <div class="stat-label">Shopping Items</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${stats.daysActive}</div>
                        <div class="stat-label">Days Active</div>
                    </div>
                </div>
                
                <div class="preferences-summary">
                    <h4>Your Dietary Preferences</h4>
                    <div class="preferences-tags">
                        ${this.preferences.length > 0 ? 
                            this.preferences.map(pref => `<span class="preference-tag">${this.formatPreferenceName(pref)}</span>`).join('') :
                            '<span class="no-preferences">No dietary preferences set</span>'
                        }
                    </div>
                </div>
                
                <div class="goals-summary">
                    <h4>Your Nutrition Goals</h4>
                    <div class="goals-grid">
                        <div class="goal-item">
                            <span>Calories:</span>
                            <span>${this.goals.calories}</span>
                        </div>
                        <div class="goal-item">
                            <span>Protein:</span>
                            <span>${this.goals.protein}g</span>
                        </div>
                        <div class="goal-item">
                            <span>Carbs:</span>
                            <span>${this.goals.carbs}g</span>
                        </div>
                        <div class="goal-item">
                            <span>Fat:</span>
                            <span>${this.goals.fat}g</span>
                        </div>
                    </div>
                </div>
            </div>
        `;

        if (window.foodExplorer) {
            foodExplorer.showCustomModal('Profile Statistics', modalContent);
        }
    }

    calculateProfileStats() {
        const meals = storage.getMeals();
        const recipes = storage.getRecipes();
        const shoppingList = storage.getShoppingList();
        const user = auth.getCurrentUser();

        const totalMeals = Object.values(meals).reduce((total, meal) => total + meal.length, 0);
        const totalRecipes = recipes.filter(recipe => recipe.author === user?.name).length;
        const shoppingItems = shoppingList.length;
        
        // Calculate days active (simplified)
        const daysActive = user ? Math.ceil((new Date() - new Date(user.createdAt)) / (1000 * 60 * 60 * 24)) : 0;

        return {
            totalMeals,
            totalRecipes,
            shoppingItems,
            daysActive
        };
    }

    formatPreferenceName(preference) {
        const names = {
            vegan: 'Vegan',
            vegetarian: 'Vegetarian',
            'gluten-free': 'Gluten-Free',
            'dairy-free': 'Dairy-Free',
            keto: 'Keto',
            paleo: 'Paleo'
        };
        return names[preference] || preference;
    }

    exportUserData() {
        const userData = {
            user: auth.getCurrentUser(),
            preferences: this.preferences,
            goals: this.goals,
            meals: storage.getMeals(),
            recipes: storage.getRecipes(),
            shoppingList: storage.getShoppingList(),
            exportDate: new Date().toISOString()
        };

        const dataStr = JSON.stringify(userData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `foodhub-data-${new Date().toISOString().split('T')[0]}.json`;
        link.click();

        URL.revokeObjectURL(url);
        navigation.showNotification('User data exported!', 'success');
    }

    importUserData() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    
                    if (data.preferences) storage.savePreferences(data.preferences);
                    if (data.goals) storage.saveGoals(data.goals);
                    if (data.meals) storage.saveMeals(data.meals);
                    if (data.recipes) storage.saveRecipes(data.recipes);
                    if (data.shoppingList) storage.saveShoppingList(data.shoppingList);
                    
                    // Reload all data
                    this.loadUserData();
                    this.updateUI();
                    
                    // Refresh other modules
                    if (window.mealPlanner) mealPlanner.init();
                    if (window.recipeManager) recipeManager.init();
                    if (window.shoppingManager) shoppingManager.init();
                    if (window.nutritionTracker) nutritionTracker.init();
                    
                    navigation.showNotification('User data imported successfully!', 'success');
                } catch (error) {
                    navigation.showNotification('Error importing data', 'error');
                }
            };
            
            reader.readAsText(file);
        };
        
        input.click();
    }

    resetAllData() {
        if (!confirm('Are you sure you want to reset ALL your data? This cannot be undone!')) {
            return;
        }

        if (!confirm('This will delete all your meals, recipes, shopping lists, and preferences. Are you absolutely sure?')) {
            return;
        }

        // Clear all data
        storage.clear();
        
        // Reset local state
        this.preferences = [];
        this.goals = DEFAULT_NUTRITION_GOALS;
        
        // Reinitialize all modules
        this.init();
        if (window.mealPlanner) mealPlanner.init();
        if (window.recipeManager) recipeManager.init();
        if (window.shoppingManager) shoppingManager.init();
        if (window.nutritionTracker) nutritionTracker.init();
        if (window.foodExplorer) foodExplorer.init();

        navigation.showNotification('All data has been reset', 'success');
    }

    calculateCalorieNeeds() {
        // Show a simple calorie calculator modal
        const modalContent = `
            <div class="calorie-calculator">
                <h3>Daily Calorie Needs Calculator</h3>
                <form id="calorie-calc-form">
                    <div class="form-group">
                        <label for="calc-age">Age</label>
                        <input type="number" id="calc-age" min="18" max="100" required>
                    </div>
                    <div class="form-group">
                        <label for="calc-gender">Gender</label>
                        <select id="calc-gender" required>
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="calc-weight">Weight (kg)</label>
                        <input type="number" id="calc-weight" min="30" max="300" required>
                    </div>
                    <div class="form-group">
                        <label for="calc-height">Height (cm)</label>
                        <input type="number" id="calc-height" min="120" max="250" required>
                    </div>
                    <div class="form-group">
                        <label for="calc-activity">Activity Level</label>
                        <select id="calc-activity" required>
                            <option value="">Select Activity Level</option>
                            <option value="sedentary">Sedentary (little/no exercise)</option>
                            <option value="light">Light (light exercise 1-3 days/week)</option>
                            <option value="moderate">Moderate (moderate exercise 3-5 days/week)</option>
                            <option value="active">Active (hard exercise 6-7 days/week)</option>
                            <option value="veryActive">Very Active (very hard exercise, physical job)</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Calculate</button>
                </form>
                <div id="calorie-result" class="hidden">
                    <h4>Your Daily Calorie Needs:</h4>
                    <div class="calorie-result-value"></div>
                    <button class="btn btn-outline" onclick="profileManager.applyCalculatedCalories()">Apply to Goals</button>
                </div>
            </div>
        `;

        if (window.foodExplorer) {
            foodExplorer.showCustomModal('Calorie Calculator', modalContent);
        }

        // Bind form submission
        const form = document.getElementById('calorie-calc-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleCalorieCalculation();
            });
        }
    }

    handleCalorieCalculation() {
        const age = parseInt(document.getElementById('calc-age').value);
        const gender = document.getElementById('calc-gender').value;
        const weight = parseFloat(document.getElementById('calc-weight').value);
        const height = parseFloat(document.getElementById('calc-height').value);
        const activity = document.getElementById('calc-activity').value;

        if (window.nutritionTracker) {
            const calories = nutritionTracker.calculateDailyCalorieNeeds(weight, height, age, gender, activity);
            
            this.calculatedCalories = calories;
            
            const resultDiv = document.getElementById('calorie-result');
            const resultValue = resultDiv.querySelector('.calorie-result-value');
            
            resultValue.innerHTML = `
                <div class="calorie-breakdown">
                    <div class="main-calories">${calories} calories/day</div>
                    <div class="calorie-note">This is an estimate based on the Mifflin-St Jeor equation</div>
                </div>
            `;
            
            resultDiv.classList.remove('hidden');
        }
    }

    applyCalculatedCalories() {
        if (this.calculatedCalories) {
            document.getElementById('calorie-goal').value = this.calculatedCalories;
            navigation.showNotification('Calculated calories applied to your goals!', 'success');
            
            if (window.foodExplorer) {
                foodExplorer.hideCustomModal();
            }
        }
    }
}

// Create global profile manager instance
const profileManager = new ProfileManager();